import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Modal,
  TouchableOpacity,
  StatusBar,
  Platform,
  SafeAreaView,
} from 'react-native';
import {useTheme} from '../modules';
import {Size, fontFamily} from '../modules';
import Icon from './Icon';

interface TermsAndConditionsModalProps {
  visible: boolean;
  onClose: () => void;
}

const TermsAndConditionsModal: React.FC<TermsAndConditionsModalProps> = ({
  visible,
  onClose,
}) => {
  const colors = useTheme();

  return (
    <Modal
      visible={visible}
      animationType="slide"
      onRequestClose={onClose}
      statusBarTranslucent>
      <SafeAreaView
        style={[styles.container, {backgroundColor: colors.background}]}>
        <View style={styles.header}>
          <Text style={[styles.title, {color: colors.text}]}>
            Terms and Conditions
          </Text>
          <TouchableOpacity
            onPress={onClose}
            activeOpacity={0.8}
            style={styles.closeButton}
            hitSlop={{top: 10, bottom: 10, left: 10, right: 10}}>
            <Icon type="AntDesign" name="close" size={24} color={colors.text} />
          </TouchableOpacity>
        </View>

        <View style={styles.divider} />

        <ScrollView
          style={styles.scrollView}
          showsVerticalScrollIndicator={false}
          bounces={false}
          contentContainerStyle={styles.scrollContent}>
          <View style={styles.contentContainer}>
            <Section
              title="Introduction"
              contentParts={[
                {
                  type: 'paragraph',
                  text: 'Welcome to Pockit Engineers ("Company," "we," "our," or "us"). These Terms and Conditions ("Terms") govern your use of our services and products, including IT services and hardware sales, provided through our website and other platforms ("Services"). By accessing or using our Services, you agree to comply with and be bound by these Terms. If you do not agree with these Terms, please do not use our Services.',
                },
              ]}
            />

            <Section
              title="Services Offered"
              contentParts={[
                {
                  type: 'paragraph',
                  text: 'PockIT Engineers provides a range of IT services, including but not limited to:',
                },
                {
                  type: 'numbered',
                  items: [
                    'IT hardware repair and maintenance.',
                    'Network setup and support.',
                    'Software installation and troubleshooting.',
                    'IT consulting services.',
                  ],
                },
                {
                  type: 'paragraph',
                  text: 'Additionally, we offer IT hardware products for sale, such as computers, peripherals, and related accessories.',
                },
              ]}
            />

            <Section
              title="User Responsibilities"
              contentParts={[
                {
                  type: 'paragraph',
                  text: 'By using our Services, you agree to:',
                },
                {
                  type: 'bulleted',
                  items: [
                    'Provide accurate and complete information when creating an account or placing an order',
                    'Maintain the confidentiality of your account credentials',
                    'Notify us immediately of any unauthorized use of your account',
                    'Use our Services only for lawful purposes and in accordance with these Terms',
                  ],
                },
              ]}
            />

            <Section
              title="Orders and Payments"
              contentParts={[
                {
                  type: 'bulleted',
                  items: [
                    'Order Acceptance: All orders for products or services are subject to acceptance by Pockit Engineers. We reserve the right to refuse or cancel any order for any reason.',
                    'Pricing: Prices for our products and services are subject to change without notice. We strive to display accurate pricing; however, errors may occur, and we reserve the right to correct them.',
                    'Payment Terms: Payment is due at the time of order placement unless otherwise agreed upon. We accept various payment methods as indicated on our website.',
                  ],
                },
              ]}
            />

            <Section
              title="Shipping and Delivery"
              contentParts={[
                {
                  type: 'bulleted',
                  items: [
                    'Shipping: We offer shipping of hardware products under specified regions. Shipping costs and delivery times will be provided at the time of purchase.',
                    'Delivery: Delivery dates are estimates between 5 to 7 days depending on location. We are not liable for delays beyond our control.',
                  ],
                },
              ]}
            />

            <Section
              title="Returns and Refunds"
              contentParts={[
                {
                  type: 'bulleted',
                  items: [
                    'Hardware Products: Returns are accepted within 5 to 7 days of purchase, provided the product is in its original condition and packaging. Refunds will be processed after inspection and will be completed within 7 days of the inspection.',
                    'Services: If you are dissatisfied with our services, please contact us at itsupport@pockitengineers.com. Refunds for services are evaluated on a case-by-case basis.',
                  ],
                },
              ]}
            />

            <Section
              title="Warranty"
              contentParts={[
                {
                  type: 'bulleted',
                  items: [
                    'Services: We provide a 180-day warranty on all repairs. If the same issue recurs within this period, we will address it at no additional cost.',
                    'Products: Hardware products come with manufacturer warranties. Please refer to the specific product warranty for details.',
                  ],
                },
              ]}
            />

            <Section
              title="Limitation of Liability"
              contentParts={[
                {
                  type: 'paragraph',
                  text: 'PockIT Engineers is not liable for any indirect, incidental, or consequential damages arising from the use of our Services or products. Our total liability is limited to the amount paid by you for the specific service or product in question.',
                },
              ]}
            />

            <Section
              title="Intellectual Property"
              contentParts={[
                {
                  type: 'paragraph',
                  text: 'All content, trademarks, and data on our website and related platforms are the property of PockIT Engineers or its licensors. Unauthorized use is prohibited.',
                },
              ]}
            />

            <Section
              title="Privacy Policy"
              contentParts={[
                {
                  type: 'paragraph',
                  text: 'Your privacy is important to us. Please review our Privacy Policy to understand how we collect, use, and protect your information.',
                },
              ]}
            />

            <Section
              title="Governing Law"
              contentParts={[
                {
                  type: 'paragraph',
                  text: 'These Terms are governed by and construed in accordance with the laws of India. Any disputes arising from these Terms or our Services shall be subject to the exclusive jurisdiction of the courts in Pune, India.',
                },
              ]}
            />

            <Section
              title="Contact Information"
              contentParts={[
                {
                  type: 'paragraph',
                  text: 'For any questions or concerns regarding these Terms or our Services, please contact us at:',
                },
                {
                  type: 'bulleted',
                  items: [
                    'Email: itsupport@pockitengineers.com',
                    'Address: PockIT Engineers, Pune, India',
                  ],
                },
              ]}
            />

            <View style={styles.footer}>
              <Text style={[styles.footerText, {color: colors.text}]}>
                By using our Services, you acknowledge that you have read,
                understood, and agree to be bound by these Terms and Conditions.
              </Text>
            </View>
          </View>
        </ScrollView>
      </SafeAreaView>
    </Modal>
  );
};

interface ContentPart {
  type: 'paragraph' | 'bulleted' | 'numbered';
  text?: string;
  items?: string[];
}

interface SectionProps {
  title: string;
  contentParts: ContentPart[];
}

const Section: React.FC<SectionProps> = ({title, contentParts}) => {
  const colors = useTheme();

  const renderBoldText = (text: string) => {
    const parts = text.split(':');
    if (parts.length > 1) {
      return (
        <Text style={[styles.sectionContent, {color: colors.text}]}>
          <Text style={[styles.sectionContent, {fontWeight: '700',color:'#020202'}]}>
            {parts[0]}:
          </Text>
          {parts[1]}
        </Text>
      );
    }
    return (
      <Text style={[styles.sectionContent, {color: colors.text}]}>{text}</Text>
    );
  };

  const renderContent = () => {
    return contentParts.map((part, partIndex) => {
      if (part.type === 'paragraph') {
        return (
          <Text
            key={partIndex}
            style={[
              styles.sectionContent,
              {color: colors.text, marginBottom: 6},
            ]}>
            {part.text}
          </Text>
        );
      } else if (part.type === 'bulleted' || part.type === 'numbered') {
        return (
          <View key={partIndex}>
            {part.items?.map((item, index) => (
              <View key={index} style={styles.bulletItem}>
                <View style={styles.bulletPoint}>
                  <Text style={styles.bulletText}>•</Text>
                </View>
                {renderBoldText(item.startsWith('• ') ? item.substring(2).trim() : item.trim())}
              </View>
            ))}
          </View>
        );
      }
      return null;
    });
  };

  return (
    <View style={styles.section}>
      <Text style={[styles.sectionTitle, {color: colors.text}]}>{title}</Text>
      {renderContent()}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight : 0,
    paddingBottom: 6,
    height: Platform.OS === 'android' ? 80 : 60,
    backgroundColor: '#fff',
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: {width: 0, height: 2},
        shadowOpacity: 0.1,
        shadowRadius: 3,
      },
      android: {
        elevation: 3,
      },
    }),
  },
  title: {
    fontSize: Size.xl,
    fontWeight: '700',
    fontFamily: fontFamily,
    flex: 1,
  },
  closeButton: {
    padding: 5,
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },

  divider: {
    height: 1,
    backgroundColor: '#E5E5E5',
    marginHorizontal: 20,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
  },
  contentContainer: {
    paddingHorizontal: 20,
    backgroundColor: '#fff',
    paddingTop: 15,
    paddingBottom: 20,
  },
  section: {
    marginBottom: 22,
  },
  sectionTitle: {
    fontSize: 15,
    fontWeight: '700',
    marginBottom: 10,
    fontFamily: fontFamily,
    color: '#1C1C28',
  },
  sectionContent: {
    fontSize: 12,
    lineHeight: 22,
    fontFamily: fontFamily,
    color: '#525252',
  },
  bulletItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  bulletPoint: {
    marginRight: 8,
    paddingTop: 2,
  },
  bulletText: {
    color: '#525252',
    fontSize: 14,
    fontWeight: 'bold',
  },
  footer: {
    paddingTop: 20,
    borderTopWidth: 1,
    borderTopColor: '#E5E5E5',
    paddingHorizontal: 20,
    backgroundColor: '#fff',
  },
  footerText: {
    fontSize: 12,
    textAlign: 'center',
    fontFamily: fontFamily,
    lineHeight: 20,
    marginBottom: 10,
    color: '#525252',
  },
});

export default TermsAndConditionsModal;
