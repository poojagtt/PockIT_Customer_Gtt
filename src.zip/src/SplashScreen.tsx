import React, { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Image,
  Modal,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Platform,
} from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import DeviceInfo from 'react-native-device-info';
import { useTranslation } from 'react-i18next';
import { AppLogo } from './assets';
import { Reducers, useDispatch } from './context';
import { apiCall, fontFamily, Size, useTheme } from './modules';
import { _styles } from './modules/stylesheet';

import Animated, {
  withTiming,
  useSharedValue,
  useAnimatedStyle,
  Easing,
} from 'react-native-reanimated';

// Images
const AppLogo1 = require('./assets/images/PokitEngginers1.png');
const AppLogo2 = require('./assets/images/PokitEngginers2.png');
const PockitEnggBottomlogo = require('./assets/images/PockitEnggBottomlogo.png');

const LOGO_SIZE = 60;
const LOGO_MARGIN = 12;

const SplashScreen = () => {
  const dispatch = useDispatch();
  const { t } = useTranslation();
  const color = useTheme();

  // Animation values
  const logo1TranslateX = useSharedValue(0);
  const logo1Scale = useSharedValue(1);
  const logo2TranslateX = useSharedValue(0);
  const logo2Opacity = useSharedValue(1);
  const showSingleLogo = useSharedValue(0);
  const positionUp = useSharedValue(0);

  // Calculate the distance between logos (logo width + margin)
  const moveDistance = LOGO_SIZE + LOGO_MARGIN;

  // Animated styles
  const logo1Style = useAnimatedStyle(() => ({
    transform: [
      { translateX: logo1TranslateX.value },
      { scale: logo1Scale.value },
    ],
    zIndex: 2,
  }));

  const logo2Style = useAnimatedStyle(() => ({
    transform: [{ translateX: logo2TranslateX.value }],
    opacity: logo2Opacity.value,
    zIndex: 1,
  }));

  const singleLogoContainerStyle = useAnimatedStyle(() => ({
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
    opacity: showSingleLogo.value,
    pointerEvents: showSingleLogo.value ? 'auto' : 'none',
  }));

  const bothLogoContainerStyle = useAnimatedStyle(() => ({
    opacity: 1 - showSingleLogo.value,
    pointerEvents: showSingleLogo.value ? 'none' : 'auto',
  }));

  const moveUpStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: positionUp.value }],
  }));

  const [versionManager, setVersionManager] = useState({
    visible: false,
    isForce: false,
    message: '',
  });

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      dispatch(Reducers.getUserInfo());
      // Animate: logo1 slides right to center, scales up; logo2 slides out and fades
      logo1TranslateX.value = withTiming(moveDistance / 2, { duration: 600, easing: Easing.out(Easing.exp) });
      logo1Scale.value = withTiming(2.2, { duration: 600, easing: Easing.out(Easing.exp) });
      logo2TranslateX.value = withTiming(moveDistance * 1.5, { duration: 600, easing: Easing.out(Easing.exp) });
      logo2Opacity.value = withTiming(0, { duration: 600, easing: Easing.out(Easing.exp) });
      setTimeout(() => {
        showSingleLogo.value = withTiming(1, { duration: 200, easing: Easing.linear });
      }, 600);
      positionUp.value = withTiming(-80, { duration: 500, easing: Easing.out(Easing.exp) });
    }, 1000);

    return () => clearTimeout(timeoutId);
  }, []);

  return (
    <SafeAreaProvider>
      <SafeAreaView style={{ flex: 1, backgroundColor: color.background }} edges={['top', 'bottom']}>
        {/* Both logos, same size, centered in a row */}
        <Animated.View style={[styles._splashContainer, styles.rowCenter, bothLogoContainerStyle]}>
          <Animated.Image
            source={AppLogo1}
            style={[styles.logoImageSmall, logo1Style]}
            resizeMode="contain"
          />
          <Animated.Image
            source={AppLogo2}
            style={[styles.logoImageSmall, logo2Style]}
            resizeMode="contain"
          />
        </Animated.View>
        {/* Single big logo, absolutely centered */}
        <Animated.View style={[singleLogoContainerStyle]}>
          <Animated.Image
            source={AppLogo1}
            style={[styles.logoImageBig]}
            resizeMode="contain"
          />
        </Animated.View>

        <Modal visible={versionManager.visible} animationType="fade" transparent>
          <View style={styles._modalContainer}>
            <View style={styles._modalContent}>
              <Image source={AppLogo} style={{ width: '100%' }} resizeMode="contain" />
            </View>
            <View style={styles._txtcontainer}>
              <Text style={styles._txt}>{t('splash.newVersionAvailable')}</Text>
              <Text style={styles._txt}>{versionManager.message}</Text>
            </View>
            <View style={styles._modalButtonContainer}>
              {!versionManager.isForce && (
                <TouchableOpacity style={styles._modalButton}>
                  <Text style={styles._modalButtonText}>{t('splash.remindLater')}</Text>
                  <ActivityIndicator style={styles._modalLoader} />
                </TouchableOpacity>
              )}
              <TouchableOpacity style={styles._modalButton}>
                <Text style={[styles._modalButtonText, { color: '#343434', fontSize: 18 }]}>
                  {t('splash.update')}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>

        <View style={styles.footerContainer}>
          {/* <Animated.Text style={[styles.footerText, moveUpStyle]}>
            Version {DeviceInfo.getVersion()} (Build {DeviceInfo.getBuildNumber()})
          </Animated.Text> */}
          <Animated.Image
            source={PockitEnggBottomlogo}
            style={[styles.bottomLogo, moveUpStyle]}
            resizeMode="contain"
          />
        </View>
      </SafeAreaView>
    </SafeAreaProvider>
  );
};

export default SplashScreen;

const styles = StyleSheet.create({
  _splashContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  rowCenter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoImageSmall: {
    width: LOGO_SIZE,
    height: LOGO_SIZE,
    marginHorizontal: LOGO_MARGIN / 2,
    backgroundColor: 'transparent',
  },
  logoImageBig: {
    width: 140,
    height: 140,
    backgroundColor: 'transparent',
  },
  _modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  _modalContent: {
    width: '40%',
    height: '20%',
    backgroundColor: '#ccc',
    borderRadius: 10,
    padding: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  _txtcontainer: {
    alignItems: 'center',
    marginTop: 40,
  },
  _txt: {
    textAlign: 'center',
    fontSize: 20,
  },
  _modalButtonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 30,
    gap: 20,
    paddingHorizontal: 20,
  },
  _modalButton: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: Size.containerPadding,
    borderRadius: 8,
    gap: 10,
    backgroundColor: '#585858',
  },
  _modalButtonText: {
    fontFamily: 'SF Pro Text',
    fontWeight: '500',
    fontSize: 16,
    lineHeight: 24,
    textAlign: 'center',
    color: '#E9E9E9',
    padding: 15,
  },
  _modalLoader: {
    position: 'absolute',
    right: Size.padding * 2,
    alignSelf: 'center',
  },
  footerContainer: {
    position: 'absolute',
    bottom: -80,
    width: '100%',
    alignItems: 'center',
    overflow: 'visible',
  },
  footerText: {
    textAlign: 'center',
    color: 'black',
    fontFamily: 'SF Pro Text',
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 8,
  },
  bottomLogo: {
    width: '80%',
    aspectRatio: 4.5,
  },
});