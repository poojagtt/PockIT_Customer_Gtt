import React, {useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
 
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import {fontFamily, Size} from '../../modules';
import {MenuRoutes} from '../../routes/Menu';
import {Header, Icon} from '../../components';
import {useTranslation} from 'react-i18next';
import Animated, {
  FadeIn,
  FadeInUp,
  FadeOut,
  FadeOutUp,
  LinearTransition,
  useDerivedValue,
  useAnimatedStyle,
  withTiming,
} from 'react-native-reanimated';

interface AboutProps extends MenuRoutes<'About'> {}

const About: React.FC<AboutProps> = ({navigation}) => {
  const {t} = useTranslation();
  const [expanded, setExpanded] = useState<{[key: string]: boolean}>({
    terms: false,
    licenses: false,
    privacy: false,
  });
  const Duration = 500;

  const toggleSection = (section: string) => {
    setExpanded(prev => ({...prev, [section]: !prev[section]}));
  };

  const rotation = {
    terms: useDerivedValue(() =>
      expanded.terms
        ? withTiming(180, {duration: Duration})
        : withTiming(0, {duration: Duration}),
    ),
    licenses: useDerivedValue(() =>
      expanded.licenses
        ? withTiming(180, {duration: Duration})
        : withTiming(0, {duration: Duration}),
    ),
    privacy: useDerivedValue(() =>
      expanded.privacy
        ? withTiming(180, {duration: Duration})
        : withTiming(0, {duration: Duration}),
    ),
  };

  const termsAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{rotate: `${rotation.terms.value}deg`}],
  }));

  const licensesAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{rotate: `${rotation.licenses.value}deg`}],
  }));

  const privacyAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{rotate: `${rotation.privacy.value}deg`}],
  }));

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View>
          <Header
            label={t('menu.about.title')}
            onBack={() => navigation.goBack()}
          />
        </View>

        <Animated.View
          layout={LinearTransition.stiffness(45).duration(Duration)}
          style={styles.card}>
          <TouchableOpacity
            onPress={() => toggleSection('terms')}
            style={styles.cardHeader}>
            <Text style={styles.cardTitle}>Terms of Service</Text>
            <Animated.View style={termsAnimatedStyle}>
              <Icon
                type="MaterialIcons"
                name="expand-more"
                size={24}
                color={'#636363'}
              />
            </Animated.View>
          </TouchableOpacity>
          {expanded.terms && (
            <Animated.View
              entering={FadeInUp.stiffness(45).duration(Duration)}
              exiting={FadeOutUp.stiffness(45)}
              style={styles.cardContent}>
              <Text style={styles.boldText}>1. Introduction</Text>
              <Text>
                Welcome to PockIT Engineers ("Company," "we," "our," or "us").
                These Terms and Conditions ("Terms") govern your use of our
                services and products, including IT services and hardware sales,
                provided through our website and other platforms ("Services").
                By accessing or using our Services, you agree to comply with and
                be bound by these Terms. If you do not agree with these Terms,
                please do not use our Services.
              </Text>

              <Text style={styles.boldText}>2. Services Offered</Text>
              <Text>
                PockIT Engineers provides a range of IT services, including but
                not limited to:
              </Text>
              <Text>{'\u2022'} IT hardware repair and maintenance.</Text>
              <Text>{'\u2022'} Network setup and support.</Text>
              <Text>{'\u2022'} Software installation and troubleshooting.</Text>
              <Text>{'\u2022'} IT consulting services.</Text>
              <Text>
                Additionally, we offer IT hardware products for sale, such as
                computers, peripherals, and related accessories.
              </Text>

              <Text style={styles.boldText}>3. User Responsibilities</Text>
              <Text>By using our Services, you agree to:</Text>
              <Text>
                {'\u2022'} Provide accurate and complete information when
                creating an account or placing an order.
              </Text>
              <Text>
                {'\u2022'} Maintain the confidentiality of your account
                credentials.
              </Text>
              <Text>
                {'\u2022'} Notify us immediately of any unauthorized use of your
                account.
              </Text>
              <Text>
                {'\u2022'} Use our Services only for lawful purposes and in
                accordance with these Terms.
              </Text>

              <Text style={styles.boldText}>4. Orders and Payments</Text>
              <Text>
                <Text style={styles.boldText}>Order Acceptance:</Text> All
                orders for products or services are subject to acceptance by
                PockIT Engineers. We reserve the right to refuse or cancel any
                order for any reason.
              </Text>
              <Text>
                <Text style={styles.boldText}>Pricing:</Text> Prices for our
                products and services are subject to change without notice. We
                strive to display accurate pricing; however, errors may occur,
                and we reserve the right to correct them.
              </Text>
              <Text>
                <Text style={styles.boldText}>Payment Terms:</Text> Payment is
                due at the time of order placement unless otherwise agreed upon.
                We accept various payment methods as indicated on our website.
              </Text>

              <Text style={styles.boldText}>5. Shipping and Delivery</Text>
              <Text>
                <Text style={styles.boldText}>Shipping:</Text> We offer shipping
                of hardware products under specified regions. Shipping costs and
                delivery times will be provided at the time of purchase.
              </Text>
              <Text>
                <Text style={styles.boldText}>Delivery:</Text> Delivery dates
                are estimates and not guaranteed. We are not liable for delays
                beyond our control.
              </Text>

              <Text style={styles.boldText}>6. Returns and Refunds</Text>
              <Text>
                <Text style={styles.boldText}>Hardware Products:</Text> Returns
                are accepted within 7 days of purchase, provided the product is
                in its original condition and packaging. Refunds will be
                processed after inspection.
              </Text>
              <Text>
                <Text style={styles.boldText}>Services:</Text> If you are
                dissatisfied with our services, please contact us at
                itsupport@pockitengineers.com. Refunds for services are evaluated
                on a case-by-case basis.
              </Text>

              <Text style={styles.boldText}>7. Warranty</Text>
              <Text>
                <Text style={styles.boldText}>Services:</Text> We provide a
                180-day warranty on all repairs. If the same issue recurs within
                this period, we will address it at no additional cost.
              </Text>
              <Text>
                <Text style={styles.boldText}>Products:</Text> Hardware products
                come with manufacturer warranties. Please refer to the specific
                product warranty for details.
              </Text>

              <Text style={styles.boldText}>8. Limitation of Liability</Text>
              <Text>
                PockIT Engineers is not liable for any indirect, incidental, or
                consequential damages arising from the use of our Services or
                products. Our total liability is limited to the amount paid by
                you for the specific service or product in question.
              </Text>

              <Text style={styles.boldText}>9. Intellectual Property</Text>
              <Text>
                All content, trademarks, and data on our website and related
                platforms are the property of PockIT Engineers or its licensors.
                Unauthorized use is prohibited.
              </Text>

              <Text style={styles.boldText}>10. Privacy Policy</Text>
              <Text>
                Your privacy is important to us. Please review our Privacy
                Policy to understand how we collect, use, and protect your
                information.
              </Text>

              <Text style={styles.boldText}>11. Governing Law</Text>
              <Text>
                These Terms are governed by and construed in accordance with the
                laws of India. Any disputes arising from these Terms or our
                Services shall be subject to the exclusive jurisdiction of the
                courts in Pune, India.
              </Text>

              <Text style={styles.boldText}>12. Contact Information</Text>
              <Text>
                For any questions or concerns regarding these Terms or our
                Services, please contact us at:
              </Text>
              <Text>
                {'\u2022'} <Text style={styles.boldText}>Email:</Text>{' '}
                itsupport@pockitengineers.com
              </Text>
              <Text>
                {'\u2022'} <Text style={styles.boldText}>Address:</Text> PockIT
                Engineers, Pune, India
              </Text>

              <Text>
                By using our Services, you acknowledge that you have read,
                understood, and agree to be bound by these Terms and Conditions.
              </Text>
            </Animated.View>
          )}
        </Animated.View>

        <Animated.View
          layout={LinearTransition.stiffness(45).duration(Duration)}
          style={styles.card}>
          <TouchableOpacity
            onPress={() => toggleSection('privacy')}
            style={styles.cardHeader}>
            <Text style={styles.cardTitle}>Privacy Policy</Text>
            <Animated.View style={privacyAnimatedStyle}>
              <Icon
                type="MaterialIcons"
                name="expand-more"
                size={24}
                color={'#636363'}
              />
            </Animated.View>
          </TouchableOpacity>
          {expanded.privacy && (
            <Animated.View
              entering={FadeInUp.stiffness(45)}
              exiting={FadeOutUp.stiffness(45)}
              style={styles.cardContent}>
              <Text style={styles.boldText}>1. Introduction</Text>
              <Text>
                PockIT Engineers ("Company," "we," "our," or "us") is committed
                to protecting your privacy. This Privacy Policy outlines how we
                collect, use, disclose, and safeguard your information when you
                use our services and products, including IT services and
                hardware sales, provided through our website and other platforms
                ("Services"). By accessing or using our Services, you agree to
                the collection and use of information in accordance with this
                policy.
              </Text>

              <Text style={styles.boldText}>2. Information We Collect</Text>
              <Text>
                We may collect and process the following types of information:
              </Text>
              <Text>
                {'\u2022'}{' '}
                <Text style={styles.boldText}>
                  Personal Identification Information:
                </Text>{' '}
                Name, email address, phone number, and postal address.
              </Text>
              <Text>
                {'\u2022'} <Text style={styles.boldText}>Technical Data:</Text>{' '}
                IP address, browser type, operating system, and access times.
              </Text>
              <Text>
                {'\u2022'} <Text style={styles.boldText}>Usage Data:</Text>{' '}
                Information about how you use our Services, such as pages
                visited and actions taken.
              </Text>
              <Text>
                {'\u2022'}{' '}
                <Text style={styles.boldText}>Transaction Data:</Text> Details
                about payments and orders you have made.
              </Text>

              <Text style={styles.boldText}>
                3. How We Use Your Information
              </Text>
              <Text>
                We use the collected information for various purposes:
              </Text>
              <Text>
                {'\u2022'}{' '}
                <Text style={styles.boldText}>
                  To Provide and Maintain Our Services:
                </Text>{' '}
                Including processing transactions and managing accounts.
              </Text>
              <Text>
                {'\u2022'}{' '}
                <Text style={styles.boldText}>To Improve Our Services:</Text>{' '}
                Analyzing usage to enhance user experience.
              </Text>
              <Text>
                {'\u2022'}{' '}
                <Text style={styles.boldText}>To Communicate with You:</Text>{' '}
                Sending updates, notifications, and promotional materials.
              </Text>
              <Text>
                {'\u2022'}{' '}
                <Text style={styles.boldText}>
                  To Comply with Legal Obligations:
                </Text>{' '}
                Ensuring adherence to applicable laws and regulations.
              </Text>

              <Text style={styles.boldText}>4. Sharing Your Information</Text>
              <Text>
                We may share your information with third parties in the
                following situations:
              </Text>
              <Text>
                {'\u2022'}{' '}
                <Text style={styles.boldText}>Service Providers:</Text> To
                perform functions on our behalf, such as payment processing and
                data analysis.
              </Text>
              <Text>
                {'\u2022'}{' '}
                <Text style={styles.boldText}>Legal Requirements:</Text> To
                comply with legal obligations or protect our rights.
              </Text>
              <Text>
                {'\u2022'}{' '}
                <Text style={styles.boldText}>Business Transfers:</Text> In
                connection with mergers, acquisitions, or asset sales.
              </Text>

              <Text style={styles.boldText}>5. Data Security</Text>
              <Text>
                We implement appropriate security measures to protect your
                information from unauthorized access, alteration, disclosure, or
                destruction. However, no method of transmission over the
                internet or electronic storage is 100% secure.
              </Text>

              <Text style={styles.boldText}>
                6. Your Data Protection Rights
              </Text>
              <Text>
                Depending on your jurisdiction, you may have the following
                rights:
              </Text>
              <Text>
                {'\u2022'} <Text style={styles.boldText}>Access:</Text> Request
                copies of your personal data.
              </Text>
              <Text>
                {'\u2022'} <Text style={styles.boldText}>Rectification:</Text>{' '}
                Request correction of inaccurate information.
              </Text>
              <Text>
                {'\u2022'} <Text style={styles.boldText}>Erasure:</Text> Request
                deletion of your personal data.
              </Text>
              <Text>
                {'\u2022'} <Text style={styles.boldText}>Restriction:</Text>{' '}
                Request restriction of processing your data.
              </Text>
              <Text>
                {'\u2022'} <Text style={styles.boldText}>Objection:</Text>{' '}
                Object to processing your data.
              </Text>
              <Text>
                {'\u2022'}{' '}
                <Text style={styles.boldText}>Data Portability:</Text> Request
                transfer of your data to another organization.
              </Text>

              <Text style={styles.boldText}>
                7. Cookies and Tracking Technologies
              </Text>
              <Text>
                We use cookies and similar tracking technologies to track
                activity on our Services and hold certain information. You can
                instruct your browser to refuse all cookies or to indicate when
                a cookie is being sent.
              </Text>

              <Text style={styles.boldText}>8. Third-Party Links</Text>
              <Text>
                Our Services may contain links to third-party websites. We are
                not responsible for the privacy practices or content of these
                sites.
              </Text>

              <Text style={styles.boldText}>
                9. Changes to This Privacy Policy
              </Text>
              <Text>
                We may update our Privacy Policy from time to time. We will
                notify you of any changes by posting the new Privacy Policy on
                this page.
              </Text>

              <Text style={styles.boldText}>10. Contact Us</Text>
              <Text>
                If you have any questions about this Privacy Policy, please
                contact us:
              </Text>
              <Text>
                <Text style={styles.boldText}>Email:</Text>{' '}
                itsupport@pockitengineers.com
              </Text>
              <Text>
                <Text style={styles.boldText}>Address:</Text> PockIT Engineers,
                Pune, India
              </Text>

              <Text>
                By using our Services, you acknowledge that you have read and
                understood this Privacy Policy and agree to its terms.
              </Text>
            </Animated.View>
          )}
        </Animated.View>

        {/* <Animated.View
          layout={LinearTransition.stiffness(45).duration(Duration)}
          style={styles.card}>
          <TouchableOpacity
            onPress={() => toggleSection('licenses')}
            style={styles.cardHeader}>
            <Text style={styles.cardTitle}>Licenses</Text>
            <Animated.View style={licensesAnimatedStyle}>
              <Icon
                type="MaterialIcons"
                name="expand-more"
                size={24}
                color={'#636363'}
              />
            </Animated.View>
          </TouchableOpacity>
          {expanded.licenses && (
            <Animated.View
              entering={FadeInUp.stiffness(45)}
              exiting={FadeOutUp.stiffness(45)}
              style={styles.cardContent}>
              <Text>
                Lorem ipsum dolor sit amet consectetur. A diam sed urna sed
                augue mi pellentesque eget. Odio mi facilisis tincidunt mi nisl
                sociis. Vel blandit neque quis non facilisi tempor et nibh.
                Massa amet quis risus auctor tellus ullamcorper vulputate
                tincidunt nisl.
              </Text>
            </Animated.View>
          )}
        </Animated.View> */}
      </ScrollView>
    </SafeAreaView>
  );
};

export default About;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // padding: 16,
    backgroundColor: '#F6F8FF',
  },
  heading: {
    fontSize: Size.xl,
    fontWeight: '700',
    color: '#1C1C28',
    marginBottom: 16,
    fontFamily: fontFamily,
  },
  card: {
    backgroundColor: '#FFFFFF',
    padding: 10,
    borderRadius: 16,
    // marginBottom: 2,
    marginTop:15,
    borderWidth: 1,
    borderColor: '#CBCBCB',
    marginHorizontal: 15,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  cardTitle: {
    fontSize: Size.lg,
    fontWeight: '500',
    color: '#0E0E0E',
    fontFamily: fontFamily,
  },
  cardContent: {
    marginTop: 8,
    fontSize: 16,
    color: '#636363',
    fontWeight: '400',
    fontFamily: fontFamily,
  },
  boldText: {
    fontWeight: 'bold',
    color: '#000',
    marginBottom: 8,
    marginTop: 8,
  },
});
