import React, {useState, useRef, useEffect} from 'react';
import {View, StyleSheet, Platform, Image} from 'react-native';
import MapView, {Marker, AnimatedRegion} from 'react-native-maps';
import database from '@react-native-firebase/database';
import {MAP_API, Permissions, Size, useTheme} from '../../../modules';
import Geolocation from 'react-native-geolocation-service';
import {MapViewRoute} from 'react-native-maps-routes';
import {_techMapIcon} from '../../../assets';
const LATITUDE_DELTA = 0.0922;
const LONGITUDE_DELTA = 0.0421;

interface props {
  jobItem: orderDetails;
}
const LocationMocking = ({jobItem}: props) => {
  const mapRef = useRef<MapView | null>(null);
  const markerRef = useRef<any>(null);
  const colors = useTheme();

  const [region, setRegion] = useState({
    latitude: 16.8524,
    longitude: 74.5815,
  });

  const [currentCoords, setCurrentCoords] = useState<null | {
    latitude: number;
    longitude: number;
  }>(null);

  useEffect(() => {
    getCurrentLocation();
  }, []);
  useEffect(() => {
    const locationRef = database().ref(`Jobs/${jobItem.JOB_CARD_ID}/location`);
    const onValueChange = locationRef.on('value', snapshot => {
      const loc = snapshot.val();
      if (loc) {
        animate(loc.latitude, loc.longitude);
        if (currentCoords) {
          mapRef.current?.fitToCoordinates(
            [
              {latitude: loc.latitude, longitude: loc.longitude},
              {
                latitude: Number(jobItem.LATITUDE),
                longitude: Number(jobItem.LONGITUDE),
              },
            ],
            {
              edgePadding: {
                top: 50,
                right: 50,
                bottom: 50,
                left: 50,
              },
              animated: true,
            },
          );
        }
        setCurrentCoords({
          latitude: loc.latitude,
          longitude: loc.longitude,
        });
      }
    });
    return () => locationRef.off('value', onValueChange);
  }, []);

  const getCurrentLocation = async () => {
    try {
      const Permission = await Permissions.checkLocation();
      if (!Permission) {
        await Permissions.requestLocation();
      } else {
        Geolocation.getCurrentPosition(
          async location => {
            let {latitude, longitude} = location.coords;
            setRegion({
              latitude: latitude,
              longitude: longitude,
            });
          },
          err => {
            console.warn('location ', err);
            {
              timeout: 2000;
            }
            getCurrentLocation();
          },
        );
      }
    } catch (error) {
      console.warn('error....', error);
    }
  };

  const animate = (latitude: number, longitude: number) => {
    const newCoordinate = {
      latitude,
      longitude,
      latitudeDelta: LATITUDE_DELTA,
      longitudeDelta: LONGITUDE_DELTA,
    };
    if (Platform.OS === 'android') {
      if (markerRef.current) {
        markerRef.current.animateMarkerToCoordinate(newCoordinate, 3000);
      }
    } else {
      // currentCoords.timing({...newCoordinate, duration: 3000}).start();
    }
  };

  return (
    <View style={styles.container}>
      <MapView
        ref={mapRef}
        // style={StyleSheet.absoluteFillObject}
        style={{height: 250, width: '100%', borderRadius: Size.radius}}
        initialRegion={{
          latitude: currentCoords
            ? currentCoords.latitude
            : Number(jobItem.LATITUDE) || region.latitude,
          longitude: currentCoords
            ? currentCoords.longitude
            : Number(jobItem.LONGITUDE) || region.longitude,
          latitudeDelta: LATITUDE_DELTA,
          longitudeDelta: LONGITUDE_DELTA,
        }}
        onMapReady={() => {
          // mapRef.current?.fitToCoordinates([], {
          //   edgePadding: {
          //     top: 50,
          //     right: 50,
          //     left: 50,
          //   },
          //   animated: true,
          // });
        }}>
        {/* technician location  */}
        {currentCoords ? (
          <Marker.Animated ref={markerRef} coordinate={currentCoords}>
            <View>
              <Image
                source={_techMapIcon}
                style={{
                  width: 40,
                  height: 40,
                }}
              />
            </View>
          </Marker.Animated>
        ) : null}
        {/* customer current location */}
        <Marker
          coordinate={{
            latitude: Number(jobItem.LATITUDE) || region.latitude,
            longitude: Number(jobItem.LONGITUDE) || region.longitude,
          }}
        />
        <MapViewRoute
          apiKey={MAP_API}
          origin={
            currentCoords
              ? {
                  latitude: currentCoords.latitude,
                  longitude: currentCoords.longitude,
                }
              : {
                  latitude: Number(jobItem.LATITUDE) || region.latitude,
                  longitude: Number(jobItem.LONGITUDE) || region.longitude,
                }
          }
          destination={{
            latitude: Number(jobItem.LATITUDE) || region.latitude,
            longitude: Number(jobItem.LONGITUDE) || region.longitude,
          }} // show customer current location
          // apikey={'AIzaSyCogGaVl4FlHx7fN3Y9bNZv3sEyWuKKMa8'}
          strokeWidth={2}
          strokeColor={colors.primary}
          // onError={errorMessage => {
          // }}
        />
      </MapView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});

export default LocationMocking;
