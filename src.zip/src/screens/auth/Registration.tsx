import messaging from '@react-native-firebase/messaging';
import React, {useCallback, useEffect, useState} from 'react';
import {useTranslation} from 'react-i18next';
import {
  Image,
  Modal,
  Text,
  View,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  Linking,
  Alert,
} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';

import {AppLogo} from '../../assets';
import {Button, CountryCodeSelector, Icon, TextInput} from '../../components';
import {Reducers, useDispatch} from '../../context';
import {getCountryCode} from '../../Functions';
import {
  apiCall,
  fontFamily,
  isValidEmail,
  isValidMobile,
  Size,
  tokenStorage,
  useStorage,
  useTheme,
} from '../../modules';
import {isValidName} from '../../modules/validations';
import {AuthRoutes} from '../../routes/Auth';
import OtpModal from './OtpModal';
import SuccessModal from '../../components/SuccessModal';
import BottomModalWithCloseButton from '../../components/BottomModalWithCloseButton';
import TermsAndConditionsModal from '../../components/TermsAndConditionsModal';

const PockItEnggColorlogo = require('../../assets/images/PokitItengineerscolor.png');

interface RegistrationProps extends AuthRoutes<'Registration'> {}
interface createPayload {
  NAME: string;
  EMAIL?: string;
  MOBILE: string;
}

const Registration: React.FC<RegistrationProps> = ({navigation, route}) => {
  const colors = useTheme();
  const dispatch = useDispatch();
  const {t} = useTranslation();
  const countryCodes = getCountryCode();
  const [userInfo, setUserInfo] = useState({
    name: '',
    email: '',
    mobile: '',
    errorName: '',
    errorEmail: '',
    errorMobile: '',
    error: '',
  });
  const [loading, setLoading] = useState(false);
  const [otp, setOtp] = useState({
    value: '',
    error: false,
    errorMessage: '',
    show: false,
  });
  const [timer, setTimer] = useState(0);
  const [selectedCountry, setSelectedCountry] = useState({
    label: '+91 (India)',
    value: '+91',
  });
  const [showCountrySelector, setShowCountrySelector] = useState(false);
  const [openReactivateModal, setOpenReactivateModal] = useState(false);
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [showTermsModal, setShowTermsModal] = useState(false);
  const getFieldErrors = () => {
    if (!submitted) {
      return {name: false, email: false, mobile: false};
    }
    const {name, email, mobile} = userInfo;
    const allEmpty = !name && !email && !mobile;
    const errors = {
      name: false,
      email: false,
      mobile: false,
    };

    if (allEmpty) {
      errors.name = errors.email = errors.mobile = true;
    } else {
      if (!name) errors.name = true;
      if (!email) errors.email = true;
      if (!mobile) errors.mobile = true;
    }
    return errors;
  };
  const [submitted, setSubmitted] = useState(false);
  const fieldErrors = getFieldErrors();
  const onCreateUser = async () => {
    const CLOUD_ID = await messaging().getToken();
    checkValidation()
      .then(body => {
        setUserInfo({
          ...userInfo,
          errorName: '',
          error: '',
          errorEmail: '',
          errorMobile: '',
        });
        apiCall
          .post(`customer/verifyOTP`, {
            TYPE: 'M',
            TYPE_VALUE: userInfo.mobile,
            OTP: otp.value,
            IS_NEW_CUSTOMER: 1,
            USER_ID: 0,
            CUSTOMER_NAME: body.NAME,
            CUSTOMER_EMAIL_ID: body.EMAIL,
            CUSTOMER_MOBILE_NO: body.MOBILE,
            CUSTOMER_CATEGORY_ID: 1,
            IS_SPECIAL_CATALOGUE: false,
            ACCOUNT_STATUS: true,
            CUSTOMER_TYPE: 'I',
            CLOUD_ID: CLOUD_ID,
            W_CLOUD_ID: CLOUD_ID,
            COUNTRY_CODE: selectedCountry.value,
          })
          .then(res => {
            if (res.data.UserData) {
              let user = res.data.UserData[0];
              let token = res.data.token;
              const topic = res.data.UserData[0]?.SUBSCRIBED_CHANNELS;
              useStorage.set('SUBSCRIBED_CHANNELS', JSON.stringify(topic));
              setOtp({
                ...otp,
                error: false,
                errorMessage: '',
                show: false,
                value: '',
              });
              tokenStorage.setToken(token);
              useStorage.set(`user`, user.USER_ID);
              if (topic) {
                topic.map(async (item: any) => {
                  await messaging()
                    .subscribeToTopic(item.CHANNEL_NAME)
                    .then(() => {});
                });
              }
              dispatch(Reducers.setSplash(true));
            } else {
              setUserInfo({
                ...userInfo,
                errorName: '',
                error: res.data.message,
                errorEmail: '',
                errorMobile: '',
              });
            }
          })
          .catch(err => {
            setUserInfo({
              ...userInfo,
              errorName: '',
              error: err
                ? err.message
                  ? err.message
                  : 'Something went wrong'
                : 'Something went wrong',
              errorEmail: '',
              errorMobile: '',
            });
            console.warn(err);
          });
      })
      .catch(error => {
        if (error.code == 'user') {
          setUserInfo({
            ...userInfo,
            errorName: error.message,
            error: '',
            errorEmail: '',
            errorMobile: '',
          });
        } else if (error.code == 'mobile') {
          setUserInfo({
            ...userInfo,
            errorName: '',
            error: '',
            errorEmail: '',
            errorMobile: error.message,
          });
        } else if (error.code == 'email') {
          setUserInfo({
            ...userInfo,
            errorName: '',
            error: '',
            errorEmail: error.message,
            errorMobile: '',
          });
        } else {
          setUserInfo({
            ...userInfo,
            errorName: '',
            error: error.message,
            errorEmail: '',
            errorMobile: '',
          });
        }
      });
  };
  // function checkValidation(): Promise<createPayload> {
  //   return new Promise((resolve, reject) => {
  //     if (!userInfo.name) {
  //       reject({
  //         code: 'user',
  //         message: t('registration.validationErrors.nameRequired'),
  //       });
  //     } else if (userInfo.name && userInfo.name.trim() == '') {
  //       reject({
  //         code: 'user',
  //         message: t('registration.validationErrors.nameEmpty'),
  //       });
  //     } else if (!userInfo.email) {
  //       reject({
  //         code: 'email',
  //         message: t('registration.validationErrors.emailRequired'),
  //       });
  //     } else if (userInfo.email && !isValidEmail(userInfo.email)) {
  //       reject({
  //         code: 'email',
  //         message: t('registration.validationErrors.emailInvalid'),
  //       });
  //     } else if (!userInfo.mobile) {
  //       reject({
  //         code: 'mobile',
  //         message: t('registration.validationErrors.mobileRequired'),
  //       });
  //     } else if (userInfo.mobile && !isValidMobile(userInfo.mobile)) {
  //       reject({
  //         code: 'mobile',
  //         message: t('registration.validationErrors.mobileInvalid'),
  //       });
  //     } else {
  //       resolve({
  //         NAME: userInfo.name,
  //         EMAIL: userInfo.email,
  //         MOBILE: userInfo.mobile,
  //       });
  //     }
  //   });
  // }

  function checkValidation(): Promise<createPayload> {
    return new Promise((resolve, reject) => {
      if (
        (!userInfo.name || userInfo.name.trim() === '') &&
        (!userInfo.email || userInfo.email.trim() === '') &&
        (!userInfo.mobile || userInfo.mobile.trim() === '')
      ) {
        reject({
          code: 'all',
          message: 'Please fill all required fields',
        });
      } else if (!userInfo.name) {
        reject({
          code: 'user',
          message: t('registration.validationErrors.nameRequired'),
        });
      } else if (userInfo.name && userInfo.name.trim() === '') {
        reject({
          code: 'user',
          message: t('registration.validationErrors.nameEmpty'),
        });
      } else if (!userInfo.email) {
        reject({
          code: 'email',
          message: t('registration.validationErrors.emailRequired'),
        });
      } else if (userInfo.email && !isValidEmail(userInfo.email)) {
        reject({
          code: 'email',
          message: t('registration.validationErrors.emailInvalid'),
        });
      } else if (!userInfo.mobile) {
        reject({
          code: 'mobile',
          message: t('registration.validationErrors.mobileRequired'),
        });
      } else if (userInfo.mobile && !isValidMobile(userInfo.mobile)) {
        reject({
          code: 'mobile',
          message: t('registration.validationErrors.mobileInvalid'),
        });
      } else if (!termsAccepted) {
        reject({
          code: 'all',
          message: t('registration.validationErrors.termsCondition'),
        });
        return;
      } else {
        resolve({
          NAME: userInfo.name,
          EMAIL: userInfo.email,
          MOBILE: userInfo.mobile,
        });
      }
    });
  }

  //   function checkValidation(): Promise<createPayload> {
  //   return new Promise((resolve, reject) => {
  //     const errors: Record<string, string> = {};

  //     if (!userInfo.name) {
  //       errors.name = t('registration.validationErrors.nameRequired');
  //     } else if (userInfo.name.trim() === '') {
  //       errors.name = t('registration.validationErrors.nameEmpty');
  //     }

  //     if (!userInfo.email) {
  //       errors.email = t('registration.validationErrors.emailRequired');
  //     } else if (!isValidEmail(userInfo.email)) {
  //       errors.email = t('registration.validationErrors.emailInvalid');
  //     }

  //     if (!userInfo.mobile) {
  //       errors.mobile = t('registration.validationErrors.mobileRequired');
  //     } else if (!isValidMobile(userInfo.mobile)) {
  //       errors.mobile = t('registration.validationErrors.mobileInvalid');
  //     }

  //     if (Object.keys(errors).length > 0) {
  //       reject(errors); // Reject with all field-specific errors
  //     } else {
  //       resolve({
  //         NAME: userInfo.name.trim(),
  //         EMAIL: userInfo.email.trim(),
  //         MOBILE: userInfo.mobile.trim(),
  //       });
  //     }
  //   });
  // }

  const timeOutCallback = useCallback(
    () => setTimer(currTimer => currTimer - 1),
    [],
  );
  useEffect(() => {
    timer > 0 && setTimeout(timeOutCallback, 1000);
  }, [timer, timeOutCallback]);
  const onRegistrationClick = () => {
    setSubmitted(true);
    setLoading(true);
    checkValidation()
      .then(body => {
        setUserInfo({
          ...userInfo,
          errorName: '',
          error: '',
          errorEmail: '',
          errorMobile: '',
        });
        apiCall
          .post(`customer/registerOtp`, {
            TYPE_VALUE: userInfo.mobile,
            COUNTRY_CODE: selectedCountry.value,
            TYPE: 'M',
            EMAIL_ID: body.EMAIL,
            MOBILE_NO: body.MOBILE,
            CUSTOMER_CATEGORY_ID: 1,
            CUSTOMER_TYPE: 'I',
          })
          .then(res => {
            if (res.status == 200 && res.data.code == 200) {
              setTimer(30);
              setOtp({...otp, show: true});
            }
            if (res.status == 200 && res.data.code == 300) {
              setUserInfo({
                ...userInfo,
                errorName: '',
                error: res.data.message,
                // error:
                //   'Oops! It looks like your account is currently deactivated. You can reach out to our support team to get it reactivated, or simply try registering with another mobile number.',
                errorEmail: '',
                errorMobile: '',
              });
            } else if (res.data.code == 301) {
              setOpenReactivateModal(true);
            }
          })
          .catch(err => {
            console.warn(err);
          })
          .finally(() => {
            setLoading(false);
          });
      })
      .catch(error => {
        if (error.code == 'user') {
          setUserInfo({
            ...userInfo,
            errorName: error.message,
            error: '',
            errorEmail: '',
            errorMobile: '',
          });
        } else if (error.code == 'mobile') {
          setUserInfo({
            ...userInfo,
            errorName: '',
            error: '',
            errorEmail: '',
            errorMobile: error.message,
          });
        } else if (error.code == 'email') {
          setUserInfo({
            ...userInfo,
            errorName: '',
            error: '',
            errorEmail: error.message,
            errorMobile: '',
          });
        } else {
          setUserInfo({
            ...userInfo,
            errorName: '',
            error: error.message,
            errorEmail: '',
            errorMobile: '',
          });
        }
        setLoading(false);
      });
  };
  const onModalClose = () => {
    setOtp({...otp, show: false});
  };
  const onResend = () => {
    checkValidation()
      .then(body => {
        setUserInfo({
          ...userInfo,
          errorName: '',
          error: '',
          errorEmail: '',
          errorMobile: '',
        });
        apiCall
          .post(`customer/registerOtp`, {
            TYPE_VALUE: userInfo.mobile,
            COUNTRY_CODE: selectedCountry.value,
            TYPE: 'M',
            EMAIL_ID: body.EMAIL,
            MOBILE_NO: body.MOBILE,
          })
          .then(res => {
            if (res.status == 200 && res.data.code == 200) {
              setTimer(30);
              setOtp({...otp, show: true, value: ''});
            }
            if (res.status == 200 && res.data.code == 300) {
              setUserInfo({
                ...userInfo,
                errorName: '',
                error: res.data.message,
                errorEmail: '',
                errorMobile: '',
              });
            }
          })
          .catch(err => {
            console.warn(err);
          })
          .finally(() => {
            setLoading(false);
          });
      })
      .catch(error => {
        if (error.code == 'user') {
          setUserInfo({
            ...userInfo,
            errorName: error.message,
            error: '',
            errorEmail: '',
            errorMobile: '',
          });
        } else if (error.code == 'mobile') {
          setUserInfo({
            ...userInfo,
            errorName: '',
            error: '',
            errorEmail: '',
            errorMobile: error.message,
          });
        } else if (error.code == 'email') {
          setUserInfo({
            ...userInfo,
            errorName: '',
            error: '',
            errorEmail: error.message,
            errorMobile: '',
          });
        } else {
          setUserInfo({
            ...userInfo,
            errorName: '',
            error: error.message,
            errorEmail: '',
            errorMobile: '',
          });
        }
        setLoading(false);
      });
  };

  const handleCustomerSupport = async () => {
    console.log('Request deletion pressed'); // Debug

    const email = 'itsupport@pockitengineers.com';
    const subject = 'Permanent Account Deletion Request';
    const body =
      'Hello,\n\nI would like to permanently delete my account. Please guide me.\n\nThanks.';
    const mailtoURL = `mailto:${email}?subject=${encodeURIComponent(
      subject,
    )}&body=${encodeURIComponent(body)}`;

    try {
      const supported = await Linking.canOpenURL(mailtoURL);
      console.log('Can open URL:', supported); // Debug

      if (supported) {
        await Linking.openURL(mailtoURL);
      } else {
        Alert.alert(
          'No Email App Found',
          'Please ensure you have a mail app set up on your device.',
        );
      }
    } catch (error) {
      console.error('Error opening mail app:', error);
      Alert.alert('Error', 'Failed to open the mail app.');
    }
  };
  return (
    <SafeAreaView
      style={{
        flex: 1,
        backgroundColor: colors.background,
        paddingHorizontal: 16,
      }}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={{flex: 1}}>
        <View style={{flex: 1, gap: 50, justifyContent: 'flex-end'}}>
          <View style={{alignItems: 'center', gap: 12}}>
            <Image
              source={AppLogo}
              style={{width: 67, height: 60}}
              resizeMode={'contain'}
            />
            <Image
              source={PockItEnggColorlogo}
              style={{width: '30%'}}
              resizeMode={'contain'}
            />

            <View style={{paddingHorizontal: 16, gap: 16}}>
              <Text
                style={{
                  fontFamily: 'SF Pro Text',
                  fontWeight: '400',
                  fontSize: 24,
                  lineHeight: 28.64,
                  letterSpacing: 0,
                  textAlign: 'center',
                  color: colors.primary,
                }}>
                {t('registration.welcome')}
              </Text>

              <Text
                style={{
                  fontFamily: 'SF Pro Text',
                  fontWeight: 400,
                  fontSize: 24,
                  lineHeight: 28.64,
                  letterSpacing: 0,
                  textAlign: 'center',
                  color: '#1C1C28',
                }}>
                {t('registration.registerTitle')}
              </Text>
            </View>
          </View>

          <View style={{gap: 10, padding: 16}}>
            <TextInput
              imp={true}
              label={t('registration.nameLabel')}
              placeholder={t('registration.namePlaceholder')}
              value={userInfo.name}
              keyboardType="default"
              onChangeText={(text: string) => {
                if (isValidName(text)) {
                  setUserInfo({
                    ...userInfo,
                    errorName: '',
                    name: text,
                  });
                } else {
                  setUserInfo({
                    ...userInfo,
                    errorName: t('registration.nameError'),
                    name: text,
                  });
                }
              }}
              error={fieldErrors.name || !!userInfo.errorName}
              errorMessage={
                userInfo.errorName ||
                (fieldErrors.name
                  ? t('registration.validationErrors.nameRequired')
                  : '')
              }
            />
            <TextInput
              imp={true}
              label={t('registration.emailLabel')}
              placeholder={t('registration.emailPlaceholder')}
              value={userInfo.email}
              keyboardType="email-address"
              placeholderTextColor={`#D2D2D2`}
              onChangeText={(text: string) =>
                setUserInfo({
                  ...userInfo,
                  errorEmail: '',
                  email: text,
                })
              }
              error={fieldErrors.email || !!userInfo.errorEmail}
              errorMessage={
                userInfo.errorEmail ||
                (fieldErrors.email
                  ? t('registration.validationErrors.emailRequired')
                  : '')
              }
            />

            <TextInput
              imp={true}
              leftChild={
                <TouchableOpacity
                  activeOpacity={0.8}
                  onPress={() => setShowCountrySelector(true)}
                  style={{
                    width: 70,
                    height: 45,
                    borderRightWidth: 1,
                    borderColor: userInfo.errorMobile
                      ? colors.error
                      : '#CBCBCB',
                    borderTopWidth: 0,
                    borderLeftWidth: 0,
                    borderBottomWidth: 0,
                    justifyContent: 'center',
                    alignItems: 'center',
                    borderRadius: 8,
                    borderTopRightRadius: 0,
                    borderBottomRightRadius: 0,
                    backgroundColor: 'transparent',
                  }}>
                  <Text
                    style={{
                      color: colors.text,
                      fontFamily: 'SF Pro Text',
                      fontSize: 16,
                    }}>
                    {selectedCountry.value}
                  </Text>
                </TouchableOpacity>
              }
              label={t('registration.mobileLabel')}
              placeholder={t('registration.mobilePlaceholder')}
              value={userInfo.mobile}
              maxLength={10}
              keyboardType="number-pad"
              onChangeText={(text: string) =>
                setUserInfo({
                  ...userInfo,
                  errorMobile: '',
                  mobile: text,
                })
              }
              error={fieldErrors.mobile || !!userInfo.errorMobile}
              errorMessage={
                userInfo.errorMobile ||
                (fieldErrors.mobile
                  ? t('registration.validationErrors.mobileRequired')
                  : '')
              }
            />

            <View>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginBottom: 16,
                  marginTop: 10,
                }}>
                <TouchableOpacity
                  onPress={() => setTermsAccepted(!termsAccepted)}
                  style={{
                    width: 20,
                    height: 20,
                    borderWidth: 1,
                    borderColor: termsAccepted ? colors.primary2 : '#999',
                    borderRadius: 4,
                    marginRight: 8,
                    backgroundColor: termsAccepted
                      ? colors.primary2
                      : 'transparent',
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}>
                  {termsAccepted && (
                    <Icon
                      type="AntDesign"
                      name="check"
                      size={14}
                      color="#fff"
                    />
                  )}
                </TouchableOpacity>
                <Text
                  style={{
                    fontSize: 14,
                    color: colors.text,
                    fontFamily: fontFamily,
                    lineHeight: 18,
                    marginLeft: 5,
                  }}>
                  I have read and agree to the{' '}
                  <Text
                    onPress={() => setShowTermsModal(true)}
                    style={{
                      color: colors.primary2,
                      textDecorationLine: 'underline',
                    }}>
                    Terms and Conditions{' '}
                  </Text>
                  of PockIT Engineers
                </Text>
              </View>
            </View>

            <CountryCodeSelector
              visible={showCountrySelector}
              onClose={() => setShowCountrySelector(false)}
              onSelect={(item: {label: string; value: string}) => {
                setSelectedCountry({
                  ...selectedCountry,
                  label: item.label,
                  value: item.value,
                });
              }}
              data={countryCodes}
              selectedCountry={selectedCountry}
            />

            {userInfo.error && (
              <Text
                style={{
                  color: colors.error,
                  textAlign: 'center',
                  lineHeight: 20,
                  letterSpacing: 0.4,
                  fontSize: 11,
                  marginTop: -6,
                }}>
                {'' + userInfo.error}
              </Text>
            )}

            <Button
              style={{
                backgroundColor: colors.primary2,
              }}
              // style={{
              //   backgroundColor: termsAccepted
              //     ? colors.primary2
              //     : '#A0A0A0',
              // }}
              label={t('registration.registerButton')}
              loading={loading}
              // disable={!termsAccepted}
              onPress={onRegistrationClick}
            />
            <View style={{gap: 24}}>
              <Text
                style={{
                  fontFamily: 'SF Pro Text',
                  fontWeight: '400',
                  fontSize: 15,
                  lineHeight: 19.53,
                  letterSpacing: 0.5,
                  textAlign: 'center',
                  color: '#525252',
                  marginBottom: 14,
                }}>
                {t('registration.haveAccount')}
                <Text
                  onPress={() => navigation.replace('Login')}
                  style={{
                    fontFamily: 'SF Pro Text',
                    fontSize: 15,
                    fontWeight: '400',
                    lineHeight: 17.9,
                    letterSpacing: 0.5,
                    textAlign: 'center',
                    color: colors.primary2,
                  }}>
                  {t('registration.login')}
                </Text>
              </Text>
            </View>

            <Text
              onPress={() => {
                useStorage.set(`user`, 0);
                dispatch(Reducers.setSplash(true));
              }}
              style={{
                fontWeight: '400',
                fontSize: 16,
                lineHeight: 19.53,
                letterSpacing: 0,
                textAlign: 'center',
                color: colors.primary2,
                marginBottom: 16,
              }}>
              {t('login.continueGuest')}
            </Text>
          </View>

          {/* otp Modal */}
          <OtpModal
            error={userInfo.error}
            visible={otp.show}
            loading={loading}
            onBack={onModalClose}
            value={otp.value}
            onChange={text =>
              setOtp({
                ...otp,
                value: text,
              })
            }
            onResend={onResend}
            onSuccess={onCreateUser}
            sendTo={`${selectedCountry.value} ${userInfo.mobile}`}
          />
          <Modal visible={loading} transparent />
        </View>
      </KeyboardAvoidingView>

      <BottomModalWithCloseButton
        onClose={() => setOpenReactivateModal(false)}
        visible={openReactivateModal}
        show={openReactivateModal}>
        <View style={{}}>
          <View
            style={{flexDirection: 'row', alignItems: 'center', marginTop: 8}}>
            <Icon type="AntDesign" name="warning" size={24} color="#000" />

            <Text
              style={{fontSize: Size.xl, fontWeight: 'bold', marginLeft: 12}}>
              Account Deactivated
            </Text>
          </View>
          <Text
            style={{
              marginTop: 16,
              fontSize: Size.md,
              fontWeight: '500',
              fontFamily: fontFamily,
              color: '#0E0E0E',
              textAlign: 'center',
            }}>
            Oops! It looks like your account is currently deactivated. You can
            reach out to our support team to get it reactivated, or simply try
            registering with another mobile number.
          </Text>

          <View style={{marginTop: 30}}>
            <Button label="Contact Support" onPress={handleCustomerSupport} />
            <Button
              outlined
              style={{marginTop: 12}}
              label="Try Another Number"
              onPress={() => {
                userInfo.mobile = '';
                setOpenReactivateModal(false);
              }}
            />
          </View>
        </View>
      </BottomModalWithCloseButton>

      <TermsAndConditionsModal
        visible={showTermsModal}
        onClose={() => setShowTermsModal(false)}
      />
    </SafeAreaView>
  );
};
export default Registration;
