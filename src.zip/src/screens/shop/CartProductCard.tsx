import React, {useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  Platform,
  TouchableOpacity,
} from 'react-native';
import {_defaultImage} from '../../assets';
import {fontFamily, IMAGE_URL, Size, useTheme} from '../../modules';
import {Button, Icon} from '../../components';
import {useTranslation} from 'react-i18next';

interface CartProductCardProps {
  product: CartProduct;
  onIncrease: (id: number) => void;
  onDecrease: (id: number) => void;
}

const CartProductCard: React.FC<CartProductCardProps> = ({
  product,
  onDecrease,
  onIncrease,
}) => {
  console.log('CartProductCard', product);
  const colors = useTheme();
  const {t} = useTranslation();
  const [loader, setLoader] = useState(false);
  return (
    <View style={{gap: 8, backgroundColor: colors.white}}>
      <View
        style={{
          width: '100%',
          height: 243,
          borderRadius: 8,
          alignSelf: 'center',
        }}>
        <Image
          source={
            product.INVENTORY_IMAGE
              ? {
                  uri:
                    IMAGE_URL +
                    'InventoryImages/' +
                    product.INVENTORY_IMAGE +
                    `?timestamp=${new Date().getTime()}`,
                 cache: 'default',
                }
              : _defaultImage
          }
          resizeMode={'cover'}
          style={{flex: 1, width: '100%', height: '100%'}}
        />
      </View>

      <TouchableOpacity style={{gap: 4, width: '100%'}}>
        <Text
          style={{
            fontSize: 16,
            fontWeight: '600',
            color: colors.text,
            fontFamily: fontFamily,
          }}>
          {product.VARIANT_COMBINATION
            ? product.VARIANT_COMBINATION
            : product?.PRODUCT_NAME?product?.PRODUCT_NAME:
product.SERVICE_NAME?product.SERVICE_NAME:''}
        </Text>
      </TouchableOpacity>
      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
          width: '100%',
          borderRadius: 8,
        }}>
        <Text
          style={{
            fontSize: 16,
            fontWeight: '400',
            color: '#636363',
            fontFamily: fontFamily,
          }}>
          {t('shop.cartProduct.quantity')}
        </Text>
        <View style={{flexDirection: 'row', alignItems: 'center', gap: 8}}>
          <>
            {/* <TouchableOpacity onPress={() => { onDecrease(product.ID) }}>
                            <Icon name="minus" type="Entypo" color={colors.text} size={20} />
                        </TouchableOpacity> */}
            <Text
              style={{
                fontSize: 16,
                fontWeight: '400',
                color: colors.text,
                borderRadius: 6,
                // borderWidth: 1,
                // borderColor: colors.black,
                // height: 28,
                // width: 28,
                textAlign: 'center',
                lineHeight: 28,
                fontFamily: fontFamily,
              }}>
              {product.QUANTITY}
            </Text>
            {/* <TouchableOpacity onPress={() => { onIncrease(product.ID) }}>
                            <Icon name="plus" type="Entypo" color={colors.text} size={20} />
                        </TouchableOpacity> */}
          </>
        </View>
      </View>
      <View style={{borderColor: colors.disable, borderBottomWidth: 1}} />
    </View>
  );
};

export default CartProductCard;

const styles = StyleSheet.create({
  cardContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    // minHeight: 337,
    width: '100%',
    //maxWidth: 358,
    fontFamily: fontFamily,
    gap: 10,
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 16,
    borderWidth: 0.5,
    borderColor: '#ddd',
    ...Platform.select({
      ios: {
        shadowColor: '#092B9C',
        shadowOffset: {width: 0, height: 0},
        shadowOpacity: 0.15,
        shadowRadius: 8,
      },
      android: {
        elevation: 4,
        shadowColor: '#092B9C',
      },
    }),
  },
});
