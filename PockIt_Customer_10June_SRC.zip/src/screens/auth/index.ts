import Login from './Login';
import Registration from './Registration';
export {Login, Registration};
