import React, {useState, useCallback, useMemo, useEffect} from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,

  TouchableOpacity,
  Alert,
  RefreshControl,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import {Icon, EmptyList, Loader} from '../../components';
import {useTheme, apiCall, fontFamily} from '../../modules';
import {_defaultImage} from '../../assets';
import ProductCard from './ProductCard';
import FilterModal from './FilterModal';
import {ShopRoutes} from '../../routes/Shops';
import {useTranslation} from 'react-i18next';

interface ProductListProps extends ShopRoutes<'ProductList'> {}

const ProductList: React.FC<ProductListProps> = ({navigation, route}) => {
  const {BRAND} = route.params || {};
  const colors = useTheme();
  const {t} = useTranslation();

  // Move getEffectivePrice function outside
  const getEffectivePrice = useCallback((product: Product) => {
    if (
      product.DISCOUNT_ALLOWED === 1 &&
      product.DISCOUNTED_PRICE > 0 &&
      product.DISCOUNTED_PRICE < product.SELLING_PRICE
    ) {
      return product.DISCOUNTED_PRICE;
    }
    return product.SELLING_PRICE;
  }, []);

  const [products, setProducts] = useState<Product[]>([]);
  const [loader, setLoader] = useState(false);
  const [pageIndex, setPageIndex] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [filter, setFilter] = useState(() => ({
    isVisible: false,
    value: {
      filter: ` AND STATUS = 1 AND IS_HAVE_VARIANTS = 0 ${
        BRAND ? ' AND BRAND_ID = ' + BRAND.ID : ''
      } AND INVENTORY_TYPE IN ("B", "P")`,
      sortKey: '',
      sortValue: '',
    },
    label: '',
  }));

  const sortedProducts = useMemo(() => {
    if (!filter.value.sortKey) return products;

    return [...products].sort((a, b) => {
      switch (filter.value.sortKey) {
        case 'ID':
          return filter.value.sortValue === 'DESC' ? b.ID - a.ID : a.ID - b.ID;
        case 'ITEM_NAME':
          return filter.value.sortValue === 'DESC'
            ? b.ITEM_NAME.localeCompare(a.ITEM_NAME)
            : a.ITEM_NAME.localeCompare(b.ITEM_NAME);
        case 'RATING':
          return filter.value.sortValue === 'DESC'
            ? (b.RATING || 0) - (a.RATING || 0)
            : (a.RATING || 0) - (b.RATING || 0);
        case 'DISCOUNTED_PRICE':
          const priceA = getEffectivePrice(a);
          const priceB = getEffectivePrice(b);

          // Sort based on the effective price, use ID as secondary sort to prevent duplicates
          if (filter.value.sortValue === 'DESC') {
            // High to Low
            return priceB === priceA
              ? a.ID - b.ID
              : Number(priceB) - Number(priceA);
          } else {
            // Low to High
            return priceA === priceB
              ? a.ID - b.ID
              : Number(priceA) - Number(priceB);
          }
        default:
          return 0;
      }
    });
  }, [
    products,
    filter.value.sortKey,
    filter.value.sortValue,
    getEffectivePrice,
  ]);

  const memoizedFilter = useMemo(() => filter, [filter]);

  const fetchInitialProducts = useCallback(async () => {
    setLoader(true);
    setProducts([]);
    try {
      const response = await apiCall.post('inventory/getForCart', {
        ...memoizedFilter.value,
        pageIndex: 1,
        pageSize: 10,
      });

      if (response.status === 200) {
        const data = response.data.data;
        setProducts(data);
        setPageIndex(2);
        setHasMore(data?.length >= 10);
      } else {
        Alert.alert(t('shop.productList.alerts.error'));
      }
    } catch (error) {
      console.error('Error in fetchInitialProducts:', error);
    } finally {
      setLoader(false);
    }
  }, [memoizedFilter, t]);

  useEffect(() => {
    fetchInitialProducts();
  }, [fetchInitialProducts]);

  const fetchMoreProducts = useCallback(async () => {
    if (loader || !hasMore) return;

    setLoader(true);
    try {
      const response = await apiCall.post('api/inventory/getForCart', {
        ...memoizedFilter.value,
        pageIndex: pageIndex,
        pageSize: 10,
      });

      if (response.status === 200) {
        const data = response.data.data;
        if (data.length > 0) {
          setProducts(prev => [...prev, ...data]);
          setPageIndex(prev => prev + 1);
          setHasMore(data.length >= 10);
        } else {
          setHasMore(false);
        }
      } else {
        Alert.alert(t('shop.productList.alerts.error'));
      }
    } catch (error) {
      console.error('Error in fetchMoreProducts:', error);
    } finally {
      setLoader(false);
    }
  }, [loader, memoizedFilter.value, pageIndex, hasMore, t]);

  const renderProduct = useCallback(
    ({item}: {item: Product}) => (
      <ProductCard
        product={item}
        onPress={() => {
          navigation.navigate('ProductDetails', {item});
        }}
        goToCart={() => navigation.navigate('CartList')}
        goToOrder={(cartID: number) =>
          navigation.navigate('PlaceOrder', {cartId: cartID})
        }
        refresh={fetchInitialProducts}
      />
    ),
    [navigation, fetchInitialProducts],
  );

  return (
    <SafeAreaView style={{flex: 1, gap: 8, backgroundColor: colors.white}}>
      <View style={styles.header}>
        <View style={{flex: 1, marginRight: 16}}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Icon
              name="arrow-back"
              type="Ionicons"
              size={24}
              color={colors.text}
            />
          </TouchableOpacity>
          <Text numberOfLines={1} style={[styles.title, {color: colors.text}]}>
            {BRAND.BRAND_NAME}
          </Text>
        </View>
        <View style={{marginTop: 20}}>
          <TouchableOpacity
            onPress={() => setFilter(prev => ({...prev, isVisible: true}))}>
            <Icon
              name="filter"
              type="AntDesign"
              size={24}
              color={colors.text}
            />
          </TouchableOpacity>
        </View>
      </View>

      {filter.label && (
        <View style={styles.filterContainer}>
          <Text style={styles.filterLabel}>{filter.label}</Text>
          <Icon
            onPress={() =>
              setFilter({
                isVisible: false,
                value: {
                  filter: ` AND STATUS = 1 AND IS_HAVE_VARIANTS = 0 ${
                    BRAND ? ' AND BRAND_ID = ' + BRAND.ID : ''
                  } AND INVENTORY_TYPE IN ("B", "P") `,
                  sortKey: '',
                  sortValue: '',
                },
                label: '',
              })
            }
            name="close"
            type="AntDesign"
            size={24}
            color={colors.text}
          />
        </View>
      )}

      <FilterModal
        visible={filter.isVisible}
        onClose={() => setFilter(prev => ({...prev, isVisible: false}))}
        onSelect={selectedFilter => {
          setFilter({
            isVisible: false,
            value: {...filter.value, ...selectedFilter.value},
            label: selectedFilter.label,
          });
        }}
      />

      <View style={{flex: 1}}>
        <FlatList
          removeClippedSubviews={false}
          data={sortedProducts}
          keyExtractor={item => `${item.ID}_${getEffectivePrice(item)}`}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={false}
              onRefresh={() => {
                setFilter({
                  isVisible: false,
                  value: {
                    filter: ` AND STATUS = 1 AND IS_HAVE_VARIANTS = 0 ${
                      BRAND ? ' AND BRAND_ID = ' + BRAND.ID : ''
                    }  `,
                    sortKey: '',
                    sortValue: '',
                  },
                  label: '',
                });
                setProducts([]);
                setPageIndex(1);
                setHasMore(true);
              }}
            />
          }
          contentContainerStyle={{
            gap: 16,
            paddingBottom: 16,
            marginHorizontal: 16,
          }}
          renderItem={renderProduct}
          ListEmptyComponent={
            !loader ? <EmptyList title={t('shop.productList.empty')} /> : null
          }
          onEndReached={fetchMoreProducts}
          onEndReachedThreshold={0.5}
        />
      </View>
      <Loader show={loader} />
    </SafeAreaView>
  );
};

export default ProductList;

const styles = StyleSheet.create({
  filterContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    marginHorizontal: 16,
    height: 40,
    // backgroundColor: '#f5f5f5',
    borderRadius: 6,
  },
  header: {
    marginTop: 8,
    marginHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  title: {
    fontFamily: 'SF Pro Text',
    fontSize: 20,
    fontWeight: '500',
  },
  filterLabel: {
    fontWeight: '500',
    fontSize: 18,
    fontFamily: fontFamily,
    color: '#636363',
  },
});
