import {View, Text, Alert, FlatList} from 'react-native';
import React, {useEffect, useState} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';
import {Header, Loader} from '../../components';
import {useTranslation} from 'react-i18next';
import {ShopRoutes} from '../../routes/Shops';
import {apiCall} from '../../modules';
import ProductCard from './ProductCard';

interface LatesALlProductProps extends ShopRoutes<'PopularBrands'> {}
const LatestAllProduct: React.FC<LatesALlProductProps> = ({navigation}) => {
  const {t} = useTranslation();
  const [loader, setLoader] = useState<boolean>(false);
  const [latestProducts, setLatestProducts] = useState<Product[]>([]);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [isLoadingMore, setIsLoadingMore] = useState<boolean>(false);
  const [hasMoreData, setHasMoreData] = useState<boolean>(true);
  const PAGE_SIZE = 10;

  useEffect(() => {
    fetchLatestProducts();
  }, []);

  const fetchLatestProducts = async (
    page: number = 1,
    isLoadMore: boolean = false,
  ) => {
    if (isLoadMore) {
      setIsLoadingMore(true);
    } else {
      setLoader(true);
    }

    try {
      const response = await apiCall.post('inventory/getForCart', {
        filter:
          ' AND STATUS = 1 AND IS_HAVE_VARIANTS = 0 AND INVENTORY_TYPE IN ("B", "P")',
        pageIndex: page,
        pageSize: PAGE_SIZE,
      });

      if (response.data.code === 200) {
        const newProducts = response.data.data;
        if (isLoadMore) {
          setLatestProducts(prev => [...prev, ...newProducts]);
        } else {
          setLatestProducts(newProducts);
        }

        // Check if we have more data to load
        setHasMoreData(newProducts.length === PAGE_SIZE);
      } else {
        Alert.alert(t('shop.productList.alerts.error'));
      }
    } catch (error) {
      console.error('Error in fetchLatestProducts:', error);
    } finally {
      setLoader(false);
      setIsLoadingMore(false);
    }
  };

  const handleLoadMore = () => {
    if (!isLoadingMore && hasMoreData) {
      const nextPage = currentPage + 1;
      setCurrentPage(nextPage);
      fetchLatestProducts(nextPage, true);
    }
  };

  return (
    <SafeAreaView
      style={{
        flex: 1,
        gap: 5,
        backgroundColor: '#FDFDFD',
      }}>
      <View>
        <Header
          label={t('shop.latest.allProduct')}
          onBack={() => navigation.goBack()}
        />
      </View>
      <View style={{flex: 1, paddingHorizontal: 14}}>
        <FlatList
          data={latestProducts}
          showsVerticalScrollIndicator={false}
          ItemSeparatorComponent={() => <View style={{height: 17}} />}
          renderItem={({item, index}) => {
            return (
              <ProductCard
                key={`${item.ID}-${index}`}
                product={item}
                onPress={() => navigation.navigate('ProductDetails', {item})}
                goToCart={() => navigation.navigate('CartList')}
                goToOrder={(cartID: number) =>
                  navigation.navigate('PlaceOrder', {cartId: cartID})
                }
                refresh={() => {
                  setCurrentPage(1);
                  fetchLatestProducts(1);
                }}
              />
            );
          }}
          onEndReached={handleLoadMore}
          onEndReachedThreshold={0.5}
          ListFooterComponent={() =>
            isLoadingMore ? (
              <View style={{paddingVertical: 20}}>
                <Loader show={true} />
              </View>
            ) : null
          }
        />
      </View>
      <Loader show={loader} />
    </SafeAreaView>
  );
};

export default LatestAllProduct;
