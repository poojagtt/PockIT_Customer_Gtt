import React, {useCallback, useEffect, useMemo, useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Image,
  TouchableOpacity,
  TextInput,
  ScrollView,
  RefreshControl,
  ActivityIndicator,
  Modal,
  Alert,
  Dimensions,
  ImageBackground,
  Platform,
} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';

import {HomeRoutes} from '../../routes/Home';
import {
  apiCall,
  IMAGE_URL,
  Size,
  useTheme,
  BASE_URL,
  fontFamily,
} from '../../modules';
import Carousel from 'react-native-reanimated-carousel';
import {Reducers, useDispatch, useSelector} from '../../context';
import {useFocusEffect} from '@react-navigation/native';
import AddressPopUp from './AddressPopUp';
import {Button, Icon} from '../../components';
import {_background, _defaultImage, _noProfile} from '../../assets';
import {useTranslation} from 'react-i18next';
import {BackHandler} from 'react-native';
import messaging from '@react-native-firebase/messaging';
import Animated, {
  Extrapolation,
  interpolate,
  useSharedValue,
} from 'react-native-reanimated';

const ImageWithFallback = ({
  source,
  fallbackSource,
  style,
  resizeMode,
}: any) => {
  const [imgSource, setImgSource] = useState(source);
  return (
    <Image
      source={imgSource}
      style={style}
      resizeMode={resizeMode}
      onError={() => setImgSource(fallbackSource)}
    />
  );
};

interface DashboardProps extends HomeRoutes<'Dashboard'> {}

interface ProgressBarPaginationProps {
  index: number;
  length: number;
  barWidth?: number;
  barHeight?: number;
  backgroundColor?: string;
  progressColor?: string;
}

const Dashboard: React.FC<DashboardProps> = ({navigation}) => {
  const colors = useTheme();
  const dispatch = useDispatch();
  const {user, address, allAddress, territory} = useSelector(
    state => state.app,
  );
  const {cart} = useSelector(state => state.cart);
  const [loading, setLoading] = useState<boolean>(false);
  const [loader, setLoader] = useState<boolean>(true);
  const [addressPopUp, setAddressPopUp] = useState<boolean>(false);
  const [b2bAddressPopUp, setB2bAddressPopUp] = useState<boolean>(false);
  const [topServices, setTopServices] = useState<ServicesInterface[]>([]);
  const [carouselImage, setCarouselImage] = useState<string[]>([]);
  const [popularBrands, setPopularBrands] = useState<any[]>([]);
  const [topSelling, setTopSelling] = useState<any[]>([]);
  const [category, setCategory] = useState<TerritoryWiseCategoryInterface[]>(
    [],
  );
  const [carouselIndex, setCarouselIndex] = useState(0);
  const [modal, setModal] = useState({
    isEnableService: false,
  });
  const {t} = useTranslation();

  async function getTerritoryWiseCategory(): Promise<void> {
    if (!address) {
      return;
    }
    setLoading(true);
    const list: TerritoryWiseCategoryInterface[] | null = await apiCall
      .post(`order/getCategories`, {
        TERRITORY_ID: address.TERRITORY_ID,
        CUSTOMER_ID: user ? user.ID : 0,
      })
      .then(res => {
        if (res.data.code == 200) {
          const data: TerritoryWiseCategoryInterface[] = res.data.data?.map(
            (item: {
              DESCRIPTION: string;
              ICON: string;
              children: {
                key: number;
                title: string;
                DESCRIPTION: string;
                ICON: string;
                BANNER_IMAGE: string;
              }[];
              disabled: boolean;
              key: number;
              title: string;
            }) => ({
              ID: item.key,
              NAME: item.title,
              DESCRIPTION: item.DESCRIPTION,
              ICON: item.ICON,
              subCategories: item.children.map(i => ({
                ID: i.key,
                NAME: i.title,
                DESCRIPTION: i.DESCRIPTION,
                IMAGE: i.ICON,
                BANNER_IMAGE: i.BANNER_IMAGE,
              })),
            }),
          );
          return data;
        } else {
          return null;
        }
      })
      .catch(err => {
        console.warn('here', err);
        return null;
      });
    setCategory(list ? list : []);
    setLoading(false);
  }
  async function getTerritoryWiseTopServices(): Promise<void> {
    const service = await apiCall
      .get(
        `app/getPoppulerServices/${user?.CUSTOMER_TYPE == 'B' ? 'B' : 'I'}/${
          user?.CUSTOMER_TYPE == 'B' ? user.ID : address?.TERRITORY_ID
        }`,
      )
      .then(res => {
        return res.data.data;
      })
      .catch(err => {
        return [];
      });

    const topService: ServicesInterface[] = service.map(
      (item: topServiceInterface) => {
        const element = cart
          ? cart.find(value => value.SERVICE_ID == item.ID)
          : null;
        return {
          IS_PARENT: item.IS_PARENT,
          QTY: Number(item.QTY),
          TOTAL_PRICE: element ? Number(element.TOTAL_PRICE) : 0,
          PRICE: Number(
            user?.CUSTOMER_TYPE == 'B' ? item.B2B_PRICE : item.B2C_PRICE,
          ),
          QUANTITY: element ? element.QUANTITY : 0,
          SERVICE_IMAGE: item.SERVICE_IMAGE,
          PREPARATION_HOURS: item.PREPARATION_HOURS,
          PREPARATION_MINUTE: item.PREPARATION_MINUTES,
          SERVICE_NAME: item.NAME,
          SERVICE_DESCRIPTION: item.DESCRIPTION,
          SERVICE_START_TIME: item.START_TIME,
          SERVICE_END_TIME: item.END_TIME,
          SERVICE_ID: item.ID,
          CART_ID: element ? element.CART_ID : 0,
          CART_ITEM_ID: element ? element.CART_ITEM_ID : 0,
          EXPRESS_CHARGES: item.EXPRESS_COST,
          CESS: item.CESS,
          CGST: item.CGST,
          IGST: item.IGST,
          SGST: item.SGST,
          IS_EXPRESS: item.IS_EXPRESS,
          MAX_QTY: Number(item.MAX_QTY),
          CATEGORY_ID: item.CATEGORY_ID,
          CATEGORY_NAME: item.CATEGORY_NAME,
          SUB_CATEGORY_ID: item.SUB_CATEGORY_ID,
          SUB_CATEGORY_NAME: item.SUB_CATEGORY_NAME,
          SERVICE_PARENT_ID: item.PARENT_ID,
          SERVICE_PARENT_NAME: item.SERVICE_NAME,
        };
      },
    );
    setTopServices(topService);
  }
  const fetchBannerData = async () => {
    try {
      const response = await apiCall
        .post('banner/get', {
          filter: ` AND STATUS = 1 AND IS_FOR_SHOP = 0 AND BANNER_TYPE = 'M' AND BANNER_FOR = 'M' `,
          sortKey: 'SEQ_NO',
          sortValue: 'desc',
        })
        .then(res => res.data);
      if (response.code == 200) {
        setCarouselImage(response.data.map((item: any) => item.IMAGE_URL));
      } else {
        Alert.alert(t('dashboard.failedBanner'));
      }
    } catch (error) {
      console.error('Error in fetchBannerData:', error);
    }
  };
  useEffect(() => {
    checkApplicationPermission();
  }, []);
  // async function checkApplicationPermission() {
  //   const authorizationStatus = await messaging().requestPermission();

  //   if (authorizationStatus === messaging.AuthorizationStatus.AUTHORIZED) {
  //     console.log('User has notification permissions enabled.');
  //   } else if (authorizationStatus === messaging.AuthorizationStatus.PROVISIONAL) {
  //     console.log('User has provisional notification permissions.');
  //   } else {
  //     console.log('User has notification permissions disabled');
  //   }
  // }

  async function checkApplicationPermission() {
    const authorizationStatus = await messaging().requestPermission();
    if (
      authorizationStatus === messaging.AuthorizationStatus.AUTHORIZED ||
      authorizationStatus === messaging.AuthorizationStatus.PROVISIONAL
    ) {
      // 👇 Required for iOS to receive remote notifications
      if (Platform.OS === 'ios') {
        await messaging().registerDeviceForRemoteMessages();
      }
      const fcmToken = await messaging().getToken();
    } else {
      // console.log('User has notification permissions disabled');
    }
  }
  useEffect(() => {
    if (!addressPopUp) {
      if (!address && user?.CUSTOMER_TYPE == 'I') {
        setAddressPopUp(true);
        setLoader(false);
      } else if (!address && user?.CUSTOMER_TYPE == 'B') {
        setB2bAddressPopUp(true);
        setLoader(false);
      } else {
        setLoader(false);
      }
    }
  }, []);
  useFocusEffect(
    useCallback(() => {
      if (address?.PINCODE_FOR == 'I') {
        setModal({
          ...modal,
          isEnableService: true,
        });
      } else {
        setModal({
          ...modal,
          isEnableService: false,
        });
      }
      address?.TERRITORY_ID ? getTerritoryWiseCategory() : setCategory([]);
      address?.TERRITORY_ID
        ? getTerritoryWiseTopServices()
        : setTopServices([]);
      fetchBannerData();
      user?.ID != 0 && fetchTopSelling();
      fetchBrandData();
    }, [address, navigation]),
  );
  const PaginationDots = ({index, length}: {index: number; length: number}) => (
    <View
      style={{
        flexDirection: 'row',
        justifyContent: 'center',
        marginTop: 8,
        marginBottom: 8,
      }}>
      {Array.from({length}).map((_, i) => (
        <View
          key={i}
          style={{
            width: index === i ? 24 : 8,
            height: 8,
            borderRadius: 4,
            marginHorizontal: 4,
            backgroundColor: index === i ? '#F36631' : '#CBCBCB',
            opacity: index === i ? 1 : 0.5,
          }}
        />
      ))}
    </View>
  );

  const ProgressBarPagination: React.FC<ProgressBarPaginationProps> = ({
    index,
    length,
    barWidth = 60,
    barHeight = 8,
    backgroundColor = '#FFF',
    progressColor = '#F36631',
  }) => {
    const progress = (index + 1) / length;
    return (
      <View
        style={{
          width: barWidth,
          height: barHeight,
          borderRadius: barHeight / 2,
          backgroundColor,
          overflow: 'hidden',
          alignSelf: 'center',
          marginTop: 12,

          // marginBottom: 8,
          borderWidth: 1,
          borderColor: '#CBCBCB',
        }}>
        <View
          style={{
            width: `${progress * 100}%`,
            height: '100%',
            backgroundColor: progressColor,
            borderRadius: barHeight / 2,
          }}
        />
      </View>
    );
  };
  const fetchBrandData = async () => {
    try {
      const response = await apiCall.post('brand/get', {
        filter: ' AND IS_POPULAR = 1 AND STATUS = 1',
        pageIndex: 1,
        pageSize: 4,
      });
      if (response.status === 200) {
        setPopularBrands(response.data.data);
      } else {
        Alert.alert(t('shop.popularBrands.error.fetch'));
      }
    } catch (error) {
      console.error('Error in fetchBrandData:', error);
    }
  };
  const fetchTopSelling = async () => {
    try {
      const response = await apiCall.post('app/getPopularInvenotry');
      if (response.status === 200) {
        setTopSelling(response.data.data);
      } else {
        Alert.alert(t('shop.popularBrands.error.fetch'));
      }
    } catch (error) {
      console.error('Error in fetchBrandData:', error);
    }
  };
  const renderValues: TerritoryWiseCategoryInterface[] = useMemo(() => {
    return category
      ? category.length > 6
        ? category.slice(0, 6)
        : category
      : [];
  }, [category]);
  const [index, setIndex] = useState(0);
  const progress = useSharedValue(0);

  const onProgressChange = (index: number) => {
    progress.value = index;
    setIndex(index);
  };
  // console.log(address?.TERRITORY_ID)
  return (
    <SafeAreaView style={{flex: 1}}>
      {loader ? (
        <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
          <ActivityIndicator color={colors.primary} size={'large'} />
        </View>
      ) : (
        <ImageBackground
          source={require('../../assets/images/background.png')}
          resizeMode="cover"
          style={{paddingHorizontal: 16, gap: 8, flex: 1}}>
          <View>
            <View
              style={{
                flexDirection: 'row',
                paddingVertical: 10,
                gap: 20,
                justifyContent: 'space-between',
                alignItems: 'center',
                borderBottomWidth: 0.5,
                marginBottom: 10,
                borderColor: '#b0c4de',
              }}>
              {address ? (
                <View
                  style={{
                    flexDirection: 'row',
                    paddingLeft: 8,
                    gap: 4,
                    flex: 1,
                  }}>
                  <TouchableOpacity
                    onPress={() => navigation.navigate('MainMenu')}>
                    <Image
                      source={
                        user?.PROFILE_PHOTO
                          ? {
                              uri: `${BASE_URL}static/CustomerProfile/${user?.PROFILE_PHOTO}`,
                              cache: 'default',
                            }
                          : _noProfile
                      }
                      style={styles._profileImage}
                    />
                  </TouchableOpacity>
                  <View style={{flex: 1, marginRight: 35}}>
                    <Text
                      numberOfLines={1}
                      style={{
                        fontFamily: fontFamily,
                        fontSize: 16,
                        fontWeight: 600,
                        lineHeight: 21.6,
                        color: colors.white,
                        opacity: 0.8,
                      }}
                      onPress={() => {
                        navigation.navigate('MainMenu');
                      }}>
                      {user?.CUSTOMER_TYPE == 'B'
                        ? user?.COMPANY_NAME
                        : user?.NAME}
                    </Text>
                    <TouchableOpacity
                      onPress={
                        user?.ID != 0
                          ? () =>
                              navigation.navigate('AddressBook', {
                                cartId: {id: null, type: null},
                              })
                          : () => setAddressPopUp(true)
                      }
                      style={{
                        flexDirection: 'row',
                        gap: 4,
                        alignItems: 'center',
                      }}>
                      <Text
                        numberOfLines={1}
                        style={{
                          fontFamily: fontFamily,
                          fontSize: 16,
                          fontWeight: 400,
                          lineHeight: 21.6,
                          color: colors.white,
                          opacity: 0.4,
                        }}>
                        {address?.ADDRESS_LINE_1}
                      </Text>
                      <Icon
                        name="chevron-down"
                        type="Ionicons"
                        color="#CBCBCB"
                      />
                    </TouchableOpacity>
                  </View>
                </View>
              ) : (
                <Text
                  onPress={() =>
                    navigation.navigate('AddressBook', {
                      cartId: {id: null, type: null},
                    })
                  }
                  style={{
                    padding: 8,
                    borderWidth: 1,
                    borderRadius: 8,
                    borderColor: '#737373',
                    fontFamily: fontFamily,
                    fontSize: 14,
                    fontWeight: 500,
                    lineHeight: 18.9,
                    color: '#0B0B0B',
                  }}>
                  {t('dashboard.selectDeliveryLocation')}
                </Text>
              )}
              <View style={{flexDirection: 'row', gap: 10}}>
                <Icon
                  name="search-outline"
                  type="Ionicons"
                  size={24}
                  color={colors.white}
                  onPress={() => navigation.navigate('SearchPage')}
                />
                {user?.ID != 0 ? (
                  <Icon
                    name="notifications-outline"
                    type="Ionicons"
                    size={24}
                    color={colors.white}
                    onPress={() => {
                      navigation.navigate('NotificationList');
                    }}
                  />
                ) : null}
              </View>
            </View>
          </View>
          <ScrollView
            refreshControl={
              <RefreshControl
                refreshing={false}
                onRefresh={() => {
                  address?.TERRITORY_ID && getTerritoryWiseCategory();
                  address?.TERRITORY_ID && getTerritoryWiseTopServices();
                  user?.ID != 0 && fetchTopSelling();
                  fetchBrandData();
                  fetchBannerData();
                }}
              />
            }
            showsVerticalScrollIndicator={false}>
            <View>
              <Text
                style={{
                  fontFamily: fontFamily,
                  fontWeight: '300',
                  fontSize: 24,
                  color: colors.white,
                }}>
                Hey there!{'\n'}Let's fix your tech issues.
              </Text>
            </View>

            {topServices.length > 0 ? (
              <View>
                {/* Title */}
                <View style={{paddingBottom: 15, marginTop: 12}}>
                  <Text
                    style={{
                      fontFamily: fontFamily,
                      fontSize: 20,
                      fontWeight: '500',
                      lineHeight: 21.48,
                      color: colors.white,
                    }}>
                    {t('dashboard.popularServices')}
                  </Text>
                </View>

                {/* List of Popular Services */}
                <FlatList
                  data={topServices}
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  removeClippedSubviews={false}
                  contentContainerStyle={{
                    paddingVertical: 2,
                    gap: 8,
                  }}
                  renderItem={({item}) => (
                    <TouchableOpacity
                      onPress={() => {
                        navigation.navigate('ServiceDetails', {
                          service: item,
                          path: [],
                        });
                      }}
                      style={{
                        gap: 8,
                        width: 134,
                        height: 134,
                        borderWidth: 1,
                        padding: 15,
                        backgroundColor: colors.white,
                        borderColor: '#CBCBCB',
                        borderRadius: 16,
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}>
                      <ImageWithFallback
                        style={{
                          width: 90,
                          height: 70,
                        }}
                        source={{
                          uri: IMAGE_URL + 'Item/' + item.SERVICE_IMAGE,
                          cache: 'default',
                        }}
                        fallbackSource={_defaultImage}
                        resizeMode="contain"
                      />
                      <Text
                        numberOfLines={2}
                        style={{
                          fontFamily: fontFamily,
                          flex: 1,
                          fontSize: 13,
                          textAlign: 'center',
                          fontWeight: '500',
                          lineHeight: 20.25,
                          color: '#000000',
                          margin: -7,
                        }}>
                        {item.SERVICE_NAME}
                      </Text>
                    </TouchableOpacity>
                  )}
                />
              </View>
            ) : (
              <View style={{alignItems: 'center'}}></View>
            )}

            {/* {user?.ID != 0 && (
              <View
                style={{
                  // flex: 1,
                  paddingHorizontal: 0,
                  borderRadius: 16,
                  // marginTop: 8,
                  // marginBottom: 15,scr
                }}>
                <Carousel
                style={{
        alignSelf: 'center', // Center the carousel
      }}
      //  panGestureHandlerProps={{
      //   activeOffsetX: [-10, 10], // Optional: tweak for better swipe
      // }}
       mode="parallax"
                  loop={carouselImage.length > 1}
  autoPlay={carouselImage.length > 1}
                  width={Size.width-14}
                  height={180}
                
                  autoPlayInterval={3000}
                  data={carouselImage}
                          onProgressChange={(_, absoluteProgress) => {
      setCarouselIndex(Math.round(absoluteProgress));
    }}

                  scrollAnimationDuration={2000}
                  renderItem={({index, item}) => {
                    return (
                      <View
                        key={index}
                        style={{
                          flex: 1,
                        }}>
                        <ImageWithFallback
                          source={{
                            uri:
                              IMAGE_URL +
                              'BannerImages/' +
                              item +
                              `?timestamp=${new Date().getTime()}`,
                            cache: 'default',
                          }}
                          fallbackSource={_defaultImage}
                          style={{
                            width: Size.width - 14,
                            height: 180,
                            borderRadius: 16,
                            borderWidth: 1,
                            borderColor: '#CBCBCB',
                          }}
                          resizeMode="cover"
                        />
                     
                      </View>
                    );
                  }}

                />

  

  <ProgressBarPagination index={carouselIndex} length={carouselImage.length} />
              </View>
              
            )} */}

            {carouselImage.length > 0 && (
              <View
                style={{
                  marginTop: 12,
                  marginBottom: 8,
                }}>
                {carouselImage.length === 1 ? (
                  // 🔹 Render full-width single banner with proper borderRadius
                  <View
                    style={{
                      width: Size.width - 30,
                      height: 150,
                      borderRadius: 16,
                      overflow: 'hidden', // Ensures image is clipped to rounded corners
                      alignSelf: 'center',
                      borderWidth: 1,
                      borderColor: '#CBCBCB',
                    }}>
                    <ImageWithFallback
                      source={{
                        uri: IMAGE_URL + 'BannerImages/' + carouselImage[0],
                        cache: 'default',
                      }}
                      fallbackSource={_defaultImage}
                      style={{
                        width: '100%',
                        height: '100%',
                      }}
                      resizeMode="cover"
                    />
                  </View>
                ) : (
                  // 🔹 Render carousel with visible next/previous banners
                  <Carousel
                    style={{
                      alignSelf: 'center',
                    }}
                    mode="parallax"
                    autoPlay={true}
                    loop={true}
                    width={Size.width - 40}
                    height={150}
                    autoPlayInterval={10000}
                    data={carouselImage}
                    onProgressChange={(_, absoluteProgress) => {
                      setCarouselIndex(Math.round(absoluteProgress));
                    }}
                    scrollAnimationDuration={2000}
                    modeConfig={{
                      parallaxScrollingScale: 0.85, // More shrink for side images
                      parallaxScrollingOffset: 70, // Increase offset for more peeking
                    }}
                    renderItem={({index, item}) => (
                      <View
                        key={index}
                        style={{
                          flex: 1,
                          borderRadius: 16,
                          overflow: 'hidden',
                          marginHorizontal: 8,
                        }}>
                        <ImageWithFallback
                          source={{
                            uri: IMAGE_URL + 'BannerImages/' + item,
                            cache: 'default',
                          }}
                          fallbackSource={_defaultImage}
                          style={{
                            width: Size.width - 40,
                            height: 150,
                            borderRadius: 16,
                            borderWidth: 1,
                            borderColor: '#CBCBCB',
                          }}
                          resizeMode="cover"
                        />
                      </View>
                    )}
                  />
                )}

                {/* 🔹 Pagination */}
                {carouselImage.length >= 1 && (
                  <ProgressBarPagination
                    index={carouselIndex}
                    length={carouselImage.length}
                  />
                )}
              </View>
            )}

            {/* category */}
            <View style={{marginTop: 12, marginBottom: 8}}>
              {/* <PaginationDots index={index} length={carouselImage.length} /> */}

              {renderValues.length > 0 ? (
                <View
                  style={{
                    paddingBottom: 10,
                    flexDirection: 'row',
                  }}>
                  <Text
                    style={{
                      fontFamily: 'SF Pro Text',
                      fontSize: 18,
                      flex: 1,
                      fontWeight: '500',
                      color: '#0E0E0E',
                      opacity: 0.8,
                    }}>
                    {t('dashboard.serviceCategories')}
                  </Text>
                  <Text
                    onPress={() =>
                      navigation.push('Category', {item: category})
                    }
                    style={{
                      fontFamily: 'SF Pro Text',
                      fontSize: 14,
                      fontWeight: '500',
                      color: '#0E0E0E',
                      opacity: 0.8,
                    }}>
                    {t('dashboard.expandAll')}
                  </Text>
                </View>
              ) : null}

              {renderValues.length > 0 ? (
                <View
                  style={{
                    flex: 1,
                    flexWrap: 'wrap',
                    flexDirection: 'row',
                    gap: 12,
                  }}>
                  {renderValues.map((item, index) => (
                    <TouchableOpacity
                      onPress={() => navigation.navigate('SubCategory', {item})}
                      key={`category_${item.ID}_${index}`}
                      style={{
                        width: (Size.width - 44) / 2,
                      }}>
                      <View
                        style={{
                          padding: Size.containerPadding,
                          // height: 167,
                          backgroundColor: 'white',
                          borderWidth: 1,
                          borderColor: '#CBCBCB',
                          borderRadius: 16,
                          shadowColor: '#000',
                          shadowOpacity: 0.1,
                          shadowOffset: {width: 0, height: 2},
                          shadowRadius: 6,
                          elevation: 2,
                        }}>
                        <Image
                          style={{
                            width: '100%',
                            height: 100,
                          }}
                          resizeMode="contain"
                          defaultSource={_defaultImage}
                          source={
                            item.ICON
                              ? {
                                  uri: IMAGE_URL + 'Category/' + item.ICON,
                                  cache: 'default',
                                }
                              : _defaultImage
                          }
                        />
                        <Text
                          style={{
                            fontFamily: 'SF Pro Text',
                            fontSize: 14,
                            textAlign: 'center',
                            fontWeight: '500',
                            color: '#0E0E0E',
                            // marginTop: 10,
                          }}
                          numberOfLines={2}>
                          {item.NAME}
                        </Text>
                      </View>
                    </TouchableOpacity>
                  ))}
                </View>
              ) : (
                <View style={{alignItems: 'center', marginTop: 20}}>
                  {address?.TERRITORY_ID ? (
                    <Text
                      style={{
                        fontFamily: 'SF Pro Text',
                        fontSize: 16,
                        fontWeight: '500',
                        color: '#888888',
                      }}>
                      Service Categories not found..!
                    </Text>
                  ) : (
                    <View
                      style={{
                        alignItems: 'center',
                        paddingHorizontal: 20,
                        backgroundColor: 'white',
                        borderRadius: 16,
                        padding: 24,
                        marginHorizontal: 16,
                        shadowColor: '#000',
                        shadowOffset: {width: 0, height: 2},
                        shadowOpacity: 0.1,
                        shadowRadius: 4,
                        elevation: 3,
                      }}>
                      <View
                        style={{
                          width: 70,
                          height: 70,
                          borderRadius: 40,
                          backgroundColor: '#FFF5F2',
                          justifyContent: 'center',
                          alignItems: 'center',
                          marginBottom: 16,
                        }}>
                        <Icon
                          name="location-outline"
                          type="Ionicons"
                          size={40}
                          color="#F36631"
                        />
                      </View>
                      <Text
                        style={{
                          fontFamily: 'SF Pro Text',
                          fontSize: 18,
                          fontWeight: '600',
                          color: '#1A1A1A',
                          textAlign: 'center',
                          marginBottom: 8,
                        }}>
                        {'Service Not Available in Your Area'}
                      </Text>
                      <Text
                        style={{
                          fontFamily: 'SF Pro Text',
                          fontSize: 14,
                          fontWeight: '400',
                          color: '#666666',
                          textAlign: 'center',
                          lineHeight: 20,
                        }}>
                        {
                          'Sorry, we are not providing service in your area yet. Please select another location.'
                        }
                      </Text>
                      {!address?.TERRITORY_ID && (
                        <TouchableOpacity
                          onPress={() =>
                            // navigation.navigate('AddressBook', {
                            //   cartId: {id: null, type: null},
                            // })
                            setAddressPopUp(true)
                          }
                          style={{
                            marginTop: 20,
                            backgroundColor: '#F36631',
                            paddingVertical: 12,
                            paddingHorizontal: 24,
                            borderRadius: 8,
                            flexDirection: 'row',
                            alignItems: 'center',
                            gap: 8,
                          }}>
                          <Icon
                            name="location-outline"
                            type="Ionicons"
                            size={16}
                            color="white"
                          />
                          <Text
                            style={{
                              fontFamily: 'SF Pro Text',
                              fontSize: 14,
                              fontWeight: '500',
                              color: 'white',
                              textAlign: 'center',
                            }}>
                            Change Address
                          </Text>
                        </TouchableOpacity>
                      )}
                    </View>
                  )}
                </View>
              )}
            </View>
          </ScrollView>
        </ImageBackground>
      )}
      {addressPopUp ? (
        <AddressPopUp
          isEdit={address ? true : false}
          addressData={address ? (address as AddressInterface) : undefined}
          onClose={address ? () => setAddressPopUp(false) : undefined}
          onSuccess={() => dispatch(Reducers.setSplash(true))}
          show={addressPopUp}
          type={null}
        />
      ) : null}
      <Modal
        transparent={true}
        visible={b2bAddressPopUp}
        onRequestClose={() => BackHandler.exitApp()}>
        <View style={styles.modalBackground}>
          <View style={styles.modalContainer}>
            <Text style={styles.modalTitle}>
              {t('home.dashboard.noAddress')}
            </Text>
            <Text style={styles.modalSubtitle}>
              {t('home.dashboard.noAddressSubtitle')}
            </Text>
          </View>
        </View>
      </Modal>
      {modal.isEnableService && (
        <View style={styles.overlayContainer}>
          <View style={styles.modalContainer}>
            <Text style={styles.modalTitle}>
              {t('home.dashboard.enableService')}
            </Text>
            <Text style={styles.modalSubtitle}>
              {t('home.dashboard.enableServiceSubtitle')}
            </Text>
          </View>
        </View>
      )}
    </SafeAreaView>
  );
};
export default Dashboard;

const styles = StyleSheet.create({
  headerContainer: {},
  categoryTitle: {
    fontSize: Size.xl,
    textAlign: 'center',
  },
  categoryDesc: {
    fontSize: Size.lg,
  },
  dot: {
    height: 10,
    borderRadius: 5,
    alignItems: 'center',
    backgroundColor: '#F4BB41',
  },
  _profileImage: {
    width: 45,
    height: 45,
    borderRadius: 95,
    borderWidth: 2.5,
    borderColor: '#FBA042',
  },
  modalBackground: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContainer: {
    margin: 15,
    padding: 12,
    backgroundColor: 'white',
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 4},
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 8,
    width: '80%',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '500',
    color: '#0E0E0E',
    textAlign: 'left',
    fontFamily: 'SF Pro Text',
  },
  modalSubtitle: {
    fontSize: 14,
    color: '#636363',
    textAlign: 'left',
    marginVertical: 4,
    marginBottom: 10,
    fontFamily: 'SF Pro Text',
  },
  overlayContainer: {
    position: 'absolute',
    top: 70,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 999,
    backgroundColor: 'rgba(0, 0, 0, 0.1)',
  },
});
