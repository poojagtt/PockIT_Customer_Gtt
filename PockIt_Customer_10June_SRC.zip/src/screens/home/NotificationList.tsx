import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Image,
  FlatList,
  RefreshControl,
 
  PermissionsAndroid,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import React, {useEffect, useState} from 'react';
import { Modal as RNModal } from 'react-native';
import { Platform } from 'react-native';

import {
  apiCall,
  fontFamily,
  Size,
  useTheme,
  IMAGE_URL,
  Permissions,
  useStorage,
} from '../../modules';
import {_noData} from '../../assets';
import {Colors} from 'react-native/Libraries/NewAppScreen';
import {Header, Icon} from '../../components';
import moment from 'moment';
import {useSelector} from '../../context';
import {HomeRoutes} from '../../routes/Home';
import messaging from '@react-native-firebase/messaging';
import {t} from 'i18next';
import RNFS from 'react-native-fs';

import {goBack} from '../../routes/navigationRef';

interface NotificationProps extends HomeRoutes<'NotificationList'> {}
const NotificationList: React.FC<NotificationProps> = ({navigation}) => {
  const colors = useTheme();
  const [loadingDownload, setLoadingDownload] = useState(false);

  const {user} = useSelector(state => state.app);
  const [notifications, setNotifications] = useState<{
    data: JobNotification[];
    isLoading: boolean;
  }>({
    data: [],
    isLoading: false,
  });

  const storedChannels = useStorage.getString('SUBSCRIBED_CHANNELS');

  let channelNames = '';
  if (storedChannels) {
    try {
      const parsedChannels = JSON.parse(storedChannels);
      channelNames = parsedChannels
        .map((item: {CHANNEL_NAME: any}) => `'${item.CHANNEL_NAME}'`)
        .join(', ');
    } catch (e) {
      console.error('Error parsing subscribed channels:', e);
    }
  }
  useEffect(() => {
    getNotifications();
    const unsubscribe = messaging().onMessage(async remoteMessage => {
      getNotifications();
    });
  }, []);

  const getNotifications = async () => {
    try {
      const response = await apiCall.post('api/notification/get', {
        filter: `AND (TYPE='C' AND MEMBER_ID=${user?.ID}) OR (TOPIC_NAME IN (${channelNames}))`,
      });
      if (response.status === 200) {
        setNotifications({
          ...notifications,
          data: response.data.data,
          isLoading: false,
        });
      }
    } catch (error) {
      setNotifications({
        ...notifications,
        isLoading: false,
      });
    }
  };
  const renderEmptyComponent = () => (
    <View style={styles.emptyContainer}>
      {/* <Icon
        name="notifications-off"
        type="MaterialIcons"
        size={50}
        color={colors.primary}
      /> */}
      <Text style={[styles.emptyText, {color: colors.text}]}>
        {t('notification.nonotificaation')}
      </Text>
      <Text
        style={{
          textAlign: 'center',
          fontSize: 14,
          fontFamily: fontFamily,
          color: '#CBCBCB',
          fontWeight: '500',
        }}>
        {t('notification.empty')}
      </Text>
      <View style={{marginTop: 25}}>
        <TouchableOpacity
          style={{
            borderWidth: 1,
            paddingHorizontal: 50,
            paddingVertical: 10,
            borderRadius: 8,
            borderColor: colors.primary2,
            backgroundColor: '#fff',
          }}
          onPress={() => goBack()}>
          <Text
            style={{
              fontFamily: fontFamily,
              color: colors.primary2,
              fontSize: 16,
              fontWeight: '500',
            }}>
            {t('notification.backTohome')}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
  if (notifications.isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  // const requestStoragePermission = async (
  //   fileUrl: string,
  //   fileName: string,
  // ) => {
  //   try {
  //     const hasPermission = await Permissions.checkStorage();
  //     if (!hasPermission) {
  //       await Permissions.requestStorage();
  //     }
  //     downloadFile(fileUrl, fileName);
  //   } catch (err) {
  //     console.warn('Storage permission error:', err);
  //     Alert.alert(
  //       'Permission Required',
  //       'Storage permission is required to download files. Please grant permission in settings.',
  //     );
  //   }
  // };


  // const requestStoragePermission = async (fileUrl: string, fileName: string) => {
  //   try {
  //     const granted = await Permissions.requestStorage();
  //     console.log("granted",granted)
  //     if (granted) {
  //       downloadFile(fileUrl, fileName);
  //     } else {
  //       Alert.alert('Permission Denied', 'Storage permission is required.');
  //     }
  //   } catch (err) {
  //     console.warn('Storage permission error:', err);
  //   }
  // };



  // const downloadFile = async (fileUrl: string, fileName: string) => {
  //   const downloadPath =
  //     Platform.OS === 'android'
  //       ? RNFS.DownloadDirectoryPath
  //       : RNFS.DocumentDirectoryPath;
  
  //   const downloadDest = `${downloadPath}/${fileName}`;
  
  //   try {
  //     const options = {
  //       fromUrl: fileUrl,
  //       toFile: downloadDest,
  //       background: true,
  //     };
  
  //     const result = RNFS.downloadFile(options);
  
  //     result.promise
  //       .then(res => {
  //         Alert.alert('Download Complete', `File saved to: ${downloadDest}`);
  //       })
  //       .catch(err => {
  //         console.log('Download error:', err);
  //         Alert.alert('Error', 'File download failed.');
  //       });
  //   } catch (error) {
  //     console.error('Download error:', error);
  //     Alert.alert('Error', 'Something went wrong during download.');
  //   }
  // };
  


  const requestStoragePermission = async () => {
    if (Platform.OS !== 'android') return true;
  
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
        {
          title: 'Storage Permission Required',
          message: 'App needs access to your storage to download files.',
          buttonNeutral: 'Ask Me Later',
          buttonNegative: 'Cancel',
          buttonPositive: 'OK',
        }
      );
      return granted === PermissionsAndroid.RESULTS.GRANTED;
    } catch (err) {
      console.warn('Permission error:', err);
      return false;
    }
  };
  
  const downloadFile = async (fileUrl: string, fileName: string, setLoadingDownload: (val: boolean) => void) => {
    if (!fileUrl || !fileName) {
      Alert.alert('Error', 'Invalid file URL or name');
      return;
    }
  
    const sanitizedFileName = fileName.replace(/[^a-zA-Z0-9.\-_]/g, '_');
  
    let downloadDest = '';
  
    if (Platform.OS === 'android') {
      const hasPermission = await requestStoragePermission();
      if (!hasPermission) {
        Alert.alert('Permission Denied', 'Cannot download file without storage permission.');
        return;
      }
      downloadDest = `${RNFS.DownloadDirectoryPath}/${sanitizedFileName}`;
    } else {
      // iOS uses DocumentDirectoryPath
      downloadDest = `${RNFS.DocumentDirectoryPath}/${sanitizedFileName}`;
    }
  
    setLoadingDownload(true);
  
    const options = {
      fromUrl: fileUrl,
      toFile: downloadDest,
      background: true,
    };
  
    try {
      const download = RNFS.downloadFile(options);
      const result = await download.promise;
  
      setLoadingDownload(false);
  
      if (result.statusCode === 200) {
        Alert.alert('Success', `File downloaded to:\n${downloadDest}`);
      } else {
        Alert.alert('Download Failed', `Status Code: ${result.statusCode}`);
      }
    } catch (error) {
      setLoadingDownload(false);
      console.error('Download error:', error);
      Alert.alert('Error', 'File download failed. Please try again.');
    }
  };
  return (
    <SafeAreaView style={styles.container}>
      <Header label={t('Notifications')} onBack={() => navigation.goBack()} />
      <View style={{paddingHorizontal:12}}>
        <FlatList
        data={notifications.data}
        removeClippedSubviews={false}
        showsVerticalScrollIndicator={false}
        renderItem={({item}) => {
          const today = moment();
          const differenceInDays = today.diff(
            item.CREATED_MODIFIED_DATE,
            'days',
          );
          let displayDate;
          if (differenceInDays > 10) {
            displayDate = moment(item.CREATED_MODIFIED_DATE).format(
              'DD/MMM/YYYY',
            );
          } else {
            differenceInDays == 0
              ? (displayDate = 'Today')
              : differenceInDays == 1
              ? (displayDate = differenceInDays + ' day')
              : (displayDate = differenceInDays + ' days');
          }
          return (
            <View style={styles.notificationItem}>
              <View style={styles.itemHeader}>
                {/* <View
                  style={[
                    styles.iconContainer,
                    {backgroundColor: colors.secondary + '50'},
                  ]}>
                  <Icon
                    name="notifications"
                    type="Ionicons"
                    size={18}
                    color={colors.primary}
                  />
                </View> */}
                <View style={styles.headerContent}>
                  <Text style={[styles.title, {color: colors.text}]}>
                    {item.TITLE.replace(/\*/g, '')}
                  </Text>
                  
                </View>
              </View>

              <View>
                <View>
                  {item.DESCRIPTION && (
                    <Text style={styles.description}>{item.DESCRIPTION}</Text>
                  )}
                </View>
                <View
                  style={{flexDirection: 'row', justifyContent: 'flex-end'}}>
                  {item.ATTACHMENT && (
                    <TouchableOpacity
                      style={styles.download}
                      onPress={() =>
                        // requestStoragePermission(
                        //   `${IMAGE_URL}notificationAttachment/${item.ATTACHMENT}`,
                        //   item.ATTACHMENT,
                        // )
                        downloadFile(
                          `${IMAGE_URL}notificationAttachment/${item.ATTACHMENT}`,
                          item.ATTACHMENT,
                          setLoadingDownload
                        )
                      }>
                      <Text style={styles.downloadtxt}>Download</Text>
                    </TouchableOpacity>
                  )}
                </View>
              </View>
              <Text style={styles.time}>
                    {`${displayDate}  |  ${moment(
                      item.CREATED_MODIFIED_DATE,
                    ).format('HH:mm a')}`}
                  </Text>
            </View>
          );
        }}
        keyExtractor={(item, index) => index.toString()}
        contentContainerStyle={styles.listContainer}
        ListEmptyComponent={renderEmptyComponent}
        refreshControl={
          <RefreshControl
            refreshing={false}
            onRefresh={() => getNotifications()}
            colors={[colors.primary]}
          />
        }
      />
      </View>
       {/* Full-Screen Loader for Language Update */}
       {loadingDownload && (
              <RNModal transparent={true} animationType="none" visible={loadingDownload}>
                <View style={styles._loaderContainer}>
                  <ActivityIndicator size="large" color={colors.primary} />
                </View>
              </RNModal>
            )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // padding: Size.containerPadding,
    backgroundColor: '#F6F8FF',
  },
  _loaderContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  headingTxt: {
    fontSize: 20,
    fontWeight: 700,
    fontFamily: fontFamily,
    color: '#1C1C28',
    marginTop: Size['2xl'],
    marginBottom: Size.lg,
  },
  listContainer: {
    flexGrow: 1,
    padding: Size.padding,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  notificationItem: {
    backgroundColor: 'white',
    paddingVertical: Size.sm,
    paddingHorizontal:Size.lg,
    marginBottom: Size.sm,
    // elevation: 2,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 1},
    shadowOpacity: 0.2,
    // shadowRadius: 2,
    borderWidth: 1,
    borderColor: '#E7E6E6',
    borderRadius: 8,
  },
  itemHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconContainer: {
    height: 34,
    width: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerContent: {
    flex: 1,
    flexDirection:'row',
    justifyContent:'space-between'
    // marginLeft: Size.radius,
  },
  title: {
    flex:1,
    fontSize: 14,
    fontWeight: '500',
  },
  time: {
    alignSelf:'flex-end',
    // flex:0.4,
    fontSize: 12,
    color: '#666',
    marginTop: 2,

  },
  description: {
    fontSize: 12,
    fontWeight:400,
    color: '#444',
    marginTop: Size.sm,
    lineHeight: 18,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    // paddingVertical: 50,
    paddingHorizontal: 16,
  },
  emptyText: {
    marginTop: Size.base,
    fontSize: 20,
    fontFamily: fontFamily,
    fontWeight: '500',
  },
  download: {
    backgroundColor: '#3170DE',
    padding: 5,
    borderRadius: 8,
    marginLeft: 10,
    marginTop: 10,
    width: 100,
  },
  downloadtxt: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '400',
    fontFamily: 'Inter',
    textAlign: 'center',
  },
});

export default NotificationList;
