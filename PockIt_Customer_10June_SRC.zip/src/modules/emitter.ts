import {EventEmitter} from 'fbemitter';
export const emitter = new EventEmitter();
